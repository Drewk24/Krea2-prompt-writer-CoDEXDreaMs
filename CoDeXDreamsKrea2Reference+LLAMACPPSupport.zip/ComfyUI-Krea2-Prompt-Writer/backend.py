import asyncio
import json
import base64
import binascii
import os
import re
import atexit
import hashlib
import shutil
import subprocess
import sys
import time
import socket
import urllib.request
import urllib.error
from pathlib import Path
from urllib.parse import urlsplit
import aiohttp
from aiohttp import web
from server import PromptServer

ROOT = Path(__file__).parent
DEFAULT = (ROOT / 'prompts' / 'writer_v2.txt').read_text(encoding='utf-8')
# Server-side setting only: browser requests cannot choose arbitrary destinations.
LLAMA_CPP_URL = os.environ.get('KREA2_LLAMA_CPP_URL', 'http://127.0.0.1:8080').rstrip('/')
LOCK = asyncio.Lock()
START_LOCK = asyncio.Lock()
BROWSE_LOCK = asyncio.Lock()
MANAGED_LLAMA = None
LAUNCH_LOG = None
# Session-only vision preset; never alters customer GGUF files.
VISION_PRESET = None

# A known compatible projector for Unsloth Gemma 4 12B Instruct.
# Pinned to a verified revision so upstream updates cannot silently replace it.
GEMMA4_MMPROJ_URL = (
    "https://huggingface.co/unsloth/gemma-4-12b-it-GGUF/resolve/63238a3/mmproj-F16.gguf"
)
GEMMA4_MMPROJ_SHA256 = "91f086971e56d7a7d8d39e271873fccdb49541bd259d6e02c401a4f1cb7a219e"
GEMMA4_MMPROJ_MAX_SIZE = 220 * 1024 * 1024

routes = PromptServer.instance.routes

class WriterError(Exception):
    pass

# The UI cannot choose executables, subprocess flags or remote servers. All
# discovery and launches are done inside the trusted, installed ComfyUI process.
# Optional user settings persist outside the extension so updates do not erase them.
def settings_path():
    if os.name == 'nt':
        base = Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local'))
        return base / 'Krea2PromptWriter' / 'settings.json'
    return Path.home() / '.config' / 'krea2-prompt-writer' / 'settings.json'


def user_settings():
    file = settings_path()
    if not file.is_file():
        return {}
    try:
        obj = json.loads(file.read_text(encoding='utf-8-sig'))
        if isinstance(obj, dict) and all(isinstance(v, str) for v in obj.values()):
            return obj
    except (OSError, ValueError, UnicodeError):
        pass
    raise WriterError(f'Invalid llama.cpp settings file: {file}. Fix JSON strings or remove it.')


def expanded_path(value):
    return Path(os.path.expandvars(os.path.expanduser(str(value).strip().strip('"'))))


def existing_executable(path):
    path = expanded_path(path)
    return path.is_file() and (os.name == 'nt' and path.suffix.lower() == '.exe' or os.access(path, os.X_OK))


def server_executable(settings):
    # Explicit local settings win; fail loudly instead of silently choosing
    # another copy of llama-server when they point to a missing file.
    specified = os.environ.get('KREA2_LLAMA_SERVER_EXE') or settings.get('llama_server_exe')
    if specified:
        path = expanded_path(specified)
        if not existing_executable(path):
            raise WriterError(f'Configured llama-server executable does not exist: {path}')
        return path.resolve()

    for filename in ('llama-server.exe', 'llama-server'):
        found = shutil.which(filename)
        if found and existing_executable(found):
            return Path(found).resolve()

    home = Path.home()
    candidates = []
    for base in (home / 'llama.cpp', home / 'llama-cpp',
                 home / 'AppData' / 'Local' / 'Programs' / 'llama.cpp',
                 Path(os.environ.get('ProgramFiles', 'C:/Program Files')) / 'llama.cpp',
                 home / 'scoop' / 'apps' / 'llama.cpp' / 'current'):
        for sub in ('', 'bin', 'build/bin', 'build/bin/Release', 'build/bin/Debug'):
            for filename in ('llama-server.exe', 'llama-server'):
                candidates.append(base / sub / filename)
    for path in candidates:
        if existing_executable(path):
            return path.resolve()
    raise WriterError('Cannot find llama-server.exe. Install llama.cpp or set "llama_server_exe" in '
                      f'{settings_path()} (no PowerShell needed).')


def model_directory(settings):
    specified = os.environ.get('KREA2_LLAMA_MODELS_DIR') or settings.get('models_dir')
    if specified:
        path = expanded_path(specified)
        if not path.is_dir():
            raise WriterError(f'Configured GGUF model folder does not exist: {path}')
        return path.resolve()

    home = Path.home()
    candidates = (home / 'llama-models', home / 'llama.cpp' / 'models',
                  home / 'models' / 'GGUF', home / 'models',
                  home / 'Downloads' / 'GGUF')
    for path in candidates:
        if path.is_dir() and any(path.glob('*.gguf')):
            return path.resolve()
    # Without --models-dir the llama.cpp router can still list the customer's
    # existing llama.cpp cache. It must NOT download models automatically.
    return None


def chosen_model(settings):
    """Only a locally picked path in our settings, never a browser-supplied path."""
    raw = settings.get('selected_model', '')
    if not raw:
        return None
    path = expanded_path(raw)
    if not path.is_file() or path.suffix.casefold() != '.gguf':
        raise WriterError(f'The previously selected GGUF model is missing: {path}. Click the folder icon to browse again.')
    if any(char in str(path) for char in ('\r', '\n')):
        raise WriterError('Invalid GGUF filename.')
    return path.resolve()


def chosen_model_id(path):
    return 'krea2-picked-' + hashlib.sha256(str(path).encode('utf-8')).hexdigest()[:12]


def gemma4_12b_model(path):
    """Only use the known Gemma 4 12B projector with that matching model family."""
    return bool(re.search(r'gemma[-_]4[-_]12b[-_]it(?:[-_.]|$)', path.name, re.I))


def cache_projector(path):
    if gemma4_12b_model(path):
        candidate = settings_path().parent / 'vision' / 'gemma-4-12b-it' / 'mmproj-F16.gguf'
        if candidate.is_file() and candidate.stat().st_size > 1024 * 1024:
            hasher = hashlib.sha256()
            with candidate.open('rb') as fp:
                for chunk in iter(lambda: fp.read(1024 * 1024), b''):
                    hasher.update(chunk)
            if hasher.hexdigest() == GEMMA4_MMPROJ_SHA256:
                return candidate.resolve()
    return None


def projector_for_model(path, settings):
    """Find a local projector first. Never change or move customer GGUF files."""
    specified = settings.get('mmproj_path') or os.environ.get('KREA2_LLAMA_MMPROJ')
    if specified:
        proj = expanded_path(specified)
        if not proj.is_file() or proj.suffix.casefold() != '.gguf':
            raise WriterError(f'Configured vision projector does not exist: {proj}')
        return proj.resolve()
    candidates = [x for x in path.parent.glob('*.gguf')
                  if x.is_file() and x != path and x.name.lower().startswith('mmproj')]
    if len(candidates) == 1:
        return candidates[0].resolve()
    preferred = [x for x in candidates if x.name.lower() == 'mmproj-f16.gguf']
    if len(preferred) == 1:
        return preferred[0].resolve()
    return cache_projector(path)


def automatic_projector(path):
    """Fetch ONLY the verified Gemma 4 12B vision companion on first image use.

    User consent is the existing Enable Reference Image toggle. Never auto-download
    language models or executables. A hard size cap, HTTPS allowlist and SHA256
    protect against substitution or partial downloads.
    """
    existing = projector_for_model(path, user_settings())
    if existing:
        return existing
    if not gemma4_12b_model(path):
        raise WriterError('This GGUF does not advertise image support and no compatible vision projector was found. '
                          'Choose a multimodal model with vision support.')
    target = settings_path().parent / 'vision' / 'gemma-4-12b-it' / 'mmproj-F16.gguf'
    target.parent.mkdir(parents=True, exist_ok=True)
    # Do not trust a stray cache file just because the name matches.
    if target.exists():
        hasher = hashlib.sha256()
        with target.open('rb') as fp:
            for chunk in iter(lambda: fp.read(1024 * 1024), b''):
                hasher.update(chunk)
        if hasher.hexdigest() == GEMMA4_MMPROJ_SHA256:
            return target.resolve()
        target.unlink()
    part = target.with_suffix('.gguf.part')
    try:
        req = urllib.request.Request(GEMMA4_MMPROJ_URL, headers={'User-Agent':'Krea2-Prompt-Writer/2.3.5'})
        with urllib.request.urlopen(req, timeout=60) as response, part.open('wb') as out:
            # Do not follow an unexpected redirect to an arbitrary host.
            final_url = urllib.parse.urlsplit(response.geturl())
            if final_url.scheme != 'https' or not (final_url.hostname == 'huggingface.co' or
                    final_url.hostname.endswith('.huggingface.co') or final_url.hostname.endswith('.hf.co') or
                    final_url.hostname.endswith('.xethub.hf.co')):
                raise WriterError('The verified Gemma vision download redirected to an unexpected host.')
            hasher = hashlib.sha256()
            total = 0
            while chunk := response.read(1024 * 1024):
                total += len(chunk)
                if total > GEMMA4_MMPROJ_MAX_SIZE:
                    raise WriterError('The Gemma vision component exceeded its expected download size.')
                hasher.update(chunk)
                out.write(chunk)
        if hasher.hexdigest() != GEMMA4_MMPROJ_SHA256:
            raise WriterError('The automatic Gemma vision download did not match its verified checksum. Nothing was installed.')
        os.replace(part, target)
        return target.resolve()
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        raise WriterError(f'Automatic Gemma vision setup could not finish ({exc}). Check the internet connection and try Write again.')
    finally:
        part.unlink(missing_ok=True)


def write_model_preset(path=None):
    """Regenerate the user-selected preset and any active vision override."""
    target = settings_path().parent / 'selected-model.ini'
    target.parent.mkdir(parents=True, exist_ok=True)
    sections = {}
    if path is not None:
        sections[chosen_model_id(path)] = (path, projector_for_model(path, user_settings()))
    if VISION_PRESET is not None:
        model_id, vision_path, projector = VISION_PRESET
        sections[model_id] = (vision_path, projector)
    contents = 'version = 1\n'
    for alias, (model_path, projector) in sections.items():
        if any(c in str(x) for x in (model_path, projector, alias) for c in ('\r', '\n', '[', ']')):
            raise WriterError('Invalid local GGUF or vision preset path.')
        contents += f'\n[{alias}]\nmodel = {model_path}\n'
        if projector:
            contents += f'mmproj = {projector}\n'
    tmp = target.with_suffix('.ini.tmp')
    tmp.write_text(contents, encoding='utf-8')
    os.replace(tmp, target)
    return target


def store_chosen_model(path):
    settings = user_settings()
    settings['selected_model'] = str(path)
    target = settings_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    # Avoid overwriting settings with partially written JSON.
    temp_file = target.with_suffix('.json.tmp')
    temp_file.write_text(json.dumps(settings, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    os.replace(temp_file, target)


def native_gguf_picker():
    """Choose on the ComfyUI computer, without uploading multi-GB weights."""
    selected = user_settings().get('selected_model')
    initial = expanded_path(selected).parent if selected else Path.home()
    if not initial.is_dir():
        initial = Path.home()
    if os.name == 'nt':
        # Win32 common file dialog avoids depending on tkinter in ComfyUI Desktop's
        # embedded Python. Run from a worker thread (not the asyncio event loop).
        import ctypes
        from ctypes import wintypes
        class OPENFILENAMEW(ctypes.Structure):
            _fields_ = [
                ('lStructSize', wintypes.DWORD), ('hwndOwner', wintypes.HWND),
                ('hInstance', wintypes.HINSTANCE), ('lpstrFilter', wintypes.LPCWSTR),
                ('lpstrCustomFilter', wintypes.LPWSTR), ('nMaxCustFilter', wintypes.DWORD),
                ('nFilterIndex', wintypes.DWORD), ('lpstrFile', wintypes.LPWSTR),
                ('nMaxFile', wintypes.DWORD), ('lpstrFileTitle', wintypes.LPWSTR),
                ('nMaxFileTitle', wintypes.DWORD), ('lpstrInitialDir', wintypes.LPCWSTR),
                ('lpstrTitle', wintypes.LPCWSTR), ('Flags', wintypes.DWORD),
                ('nFileOffset', wintypes.WORD), ('nFileExtension', wintypes.WORD),
                ('lpstrDefExt', wintypes.LPCWSTR), ('lCustData', wintypes.LPARAM),
                ('lpfnHook', ctypes.c_void_p), ('lpTemplateName', wintypes.LPCWSTR),
                ('pvReserved', ctypes.c_void_p), ('dwReserved', wintypes.DWORD),
                ('FlagsEx', wintypes.DWORD),
            ]
        buffer = ctypes.create_unicode_buffer(32768)
        ofn = OPENFILENAMEW()
        ofn.lStructSize = ctypes.sizeof(OPENFILENAMEW)
        ofn.lpstrFilter = 'GGUF models (*.gguf)\0*.gguf\0All files (*.*)\0*.*\0\0'
        ofn.lpstrFile = ctypes.cast(buffer, wintypes.LPWSTR)
        ofn.nMaxFile = len(buffer)
        ofn.lpstrInitialDir = str(initial)
        ofn.lpstrTitle = 'Krea 2 Prompt Writer — Choose a GGUF model'
        ofn.Flags = 0x00080000 | 0x00001000 | 0x00000800 | 0x00000004  # explorer, file must exist, path must exist, hide readonly
        dlg = ctypes.windll.comdlg32
        dlg.GetOpenFileNameW.argtypes = [ctypes.POINTER(OPENFILENAMEW)]
        dlg.GetOpenFileNameW.restype = wintypes.BOOL
        if not dlg.GetOpenFileNameW(ctypes.byref(ofn)):
            err = dlg.CommDlgExtendedError()
            if err:
                raise WriterError(f'Windows could not open the GGUF file picker (dialog error {err}).')
            return None  # Cancel is not an error.
        return Path(buffer.value)
    # For local non-Windows ComfyUI installations.
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes('-topmost', True)
        try:
            result = filedialog.askopenfilename(parent=root, title='Choose a GGUF model',
                        initialdir=str(initial), filetypes=[('GGUF models', '*.gguf')])
        finally:
            root.destroy()
        return Path(result) if result else None
    except Exception as exc:
        raise WriterError(f'No native file picker is available on this ComfyUI machine: {exc}')


def local_port():
    parsed = urlsplit(LLAMA_CPP_URL)
    if parsed.scheme != 'http' or parsed.hostname not in ('127.0.0.1', 'localhost', '::1') or parsed.username or parsed.password or parsed.path not in ('', '/') or parsed.query or parsed.fragment:
        raise WriterError('Automatic llama.cpp startup is supported only for an HTTP loopback URL (127.0.0.1/localhost).')
    try:
        return parsed.port or 80
    except ValueError:
        raise WriterError('Invalid local llama.cpp port.')


def free_loopback_endpoint():
    # Create a secondary Writer-owned server without stopping someone else's router.
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(('127.0.0.1', 0))
        return 'http://127.0.0.1:' + str(listener.getsockname()[1])


def launch_server():
    global MANAGED_LLAMA, LAUNCH_LOG
    settings = user_settings()
    executable = server_executable(settings)
    models = model_directory(settings)
    selected = chosen_model(settings)
    port = local_port()
    args = [str(executable), '--host', '127.0.0.1', '--port', str(port),
            '--models-max', '1', '-c', '8192', '-ngl', '99']
    if models is not None:
        args.extend(['--models-dir', str(models)])
    if selected is not None or VISION_PRESET is not None:
        args.extend(['--models-preset', str(write_model_preset(selected))])
    log_path = settings_path().parent / 'llama-server.log'
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        # New launch replaces the old log, so errors are readable for users.
        log_file = open(log_path, 'w', encoding='utf-8')
        log_file.write(f'Launched: {executable}\nModels folder: {models or "llama.cpp cache"}\n')
        log_file.flush()
        flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0
        clean_env = os.environ.copy()
        # Discard inherited flags that force an unrelated model/configuration.
        for var in ('LLAMA_ARG_MODEL', 'LLAMA_ARG_HF_REPO', 'LLAMA_ARG_HF_FILE',
                    'LLAMA_ARG_MODELS_PRESET', 'LLAMA_ARG_MODELS_DIR'):
            clean_env.pop(var, None)
        try:
            proc = subprocess.Popen(args, cwd=str(executable.parent),
                                    stdin=subprocess.DEVNULL, stdout=log_file,
                                    stderr=subprocess.STDOUT, creationflags=flags,
                                    env=clean_env)
        finally:
            log_file.close()
    except OSError as exc:
        raise WriterError(f'Could not start llama.cpp: {exc}. See {log_path}')
    MANAGED_LLAMA = proc
    LAUNCH_LOG = log_path
    return proc


def stop_managed_llama():
    global MANAGED_LLAMA
    process = MANAGED_LLAMA
    MANAGED_LLAMA = None
    if process is not None:
        if process.poll() is None:
            try:
                process.terminate()
                process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=2)
            except OSError:
                pass
        else:
            # Reap an exited child to avoid leaving it as a zombie.
            process.wait()


atexit.register(stop_managed_llama)


async def probe_router():
    """Return 'ready', 'absent', or 'occupied'; never assume a port is ours."""
    timeout = aiohttp.ClientTimeout(total=2.5)
    try:
        async with aiohttp.ClientSession(timeout=timeout, trust_env=False) as session:
            async with session.get(LLAMA_CPP_URL + '/models', allow_redirects=False) as response:
                if response.status != 200:
                    return 'occupied'
                try:
                    body = await response.json()
                except (ValueError, aiohttp.ContentTypeError):
                    return 'occupied'
                return 'ready' if isinstance(body, dict) and isinstance(body.get('data'), list) else 'occupied'
    except (aiohttp.ClientConnectorError, aiohttp.ClientConnectionError, asyncio.TimeoutError):
        return 'absent'


async def ensure_llama_ready():
    """Start once on demand (opening the writer or writing), never at import."""
    if await probe_router() == 'ready':
        return False
    async with START_LOCK:
        status = await probe_router()
        if status == 'ready':
            return False
        if status == 'occupied':
            raise WriterError(f'Port {local_port()} has another service or llama.cpp single-model mode. '
                              'Close that server, or use a free port for the writer.')
        local_port()  # Reject unexpected destinations even if not reachable.
        global MANAGED_LLAMA
        if MANAGED_LLAMA is None or MANAGED_LLAMA.poll() is not None:
            process = launch_server()
            started = True
        else:
            process = MANAGED_LLAMA
            started = False
        # The router loads GGUF on demand, so startup should be quick. If it
        # fails, surface the log location instead of hanging the ComfyUI UI.
        deadline = asyncio.get_running_loop().time() + 25
        while asyncio.get_running_loop().time() < deadline:
            await asyncio.sleep(0.35)
            status = await probe_router()
            if status == 'ready':
                return started
            if process.poll() is not None:
                raise WriterError(f'llama.cpp exited while starting (code {process.returncode}). '
                                  f'Check {LAUNCH_LOG}.')
            if status == 'occupied':
                raise WriterError(f'Port {local_port()} is occupied by another service. Check {LAUNCH_LOG}.')
        raise WriterError(f'llama.cpp did not become ready in 25 seconds. Check {LAUNCH_LOG}.')

def clean_output(text):
    text = re.sub(r'<think\b[^>]*>.*?</think>', '', text, flags=re.S | re.I)
    if re.search(r'<think\b', text, flags=re.I):
        raise WriterError('The model returned unfinished thinking. Increase Max output tokens or choose another model.')
    text = text.strip()
    if not text:
        raise WriterError('The model returned no prompt. Increase Max output tokens or choose another model.')
    return text

def check_reference(data):
    enabled = data.get('reference_enabled', False)
    if not isinstance(enabled, bool):
        raise ValueError('Enable Reference Image must be a true/false value.')
    if not enabled:
        return None  # Disabled means even a supplied image never reaches llama.cpp.
    raw = data.get('reference_image')
    if not isinstance(raw, str) or not raw.startswith('data:image/jpeg;base64,'):
        raise ValueError('Choose a reference image before writing, or turn off the reference toggle.')
    if len(raw) > 8 * 1024 * 1024:
        raise ValueError('Reference image is too large after compression.')
    encoded = raw.split(',', 1)[1]
    try:
        decoded = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error):
        raise ValueError('Reference image encoding is invalid.')
    if not (decoded.startswith(b'\xff\xd8\xff') and decoded.endswith(b'\xff\xd9')):
        raise ValueError('Reference image must be a valid JPEG.')
    if len(decoded) > 6 * 1024 * 1024:
        raise ValueError('Reference image is too large.')
    return raw


def payload(data):
    if not isinstance(data, dict):
        raise ValueError('Expected a JSON object.')
    model = data.get('model', '')
    brief = data.get('brief', '')
    system = data.get('system', DEFAULT)
    for name, value, limit in [('model', model, 512), ('brief', brief, 24000), ('system', system, 24000)]:
        if not isinstance(value, str) or not value.strip() or len(value) > limit:
            raise ValueError(f'{name} must contain 1–{limit} characters.')
    tokens = int(data.get('max_tokens', 1536))
    if not 256 <= tokens <= 8192:
        raise ValueError('Max output tokens must be between 256 and 8192.')
    temperature = float(data.get('temperature', 0.7))
    if not 0 <= temperature <= 2:
        raise ValueError('Temperature must be between 0 and 2.')
    style = data.get('style', 'Follow my brief')
    length = data.get('length', 'Balanced')
    mode = data.get('mode', 'New image')
    keep = data.get('must_keep', '')
    if style not in ['Follow my brief', '2D comic / cel shaded', 'Anime / hand drawn', 'Photograph', '3D render'] or length not in ['Short', 'Balanced', 'Detailed'] or mode not in ['New image', 'Reference / edit']:
        raise ValueError('Invalid writing option.')
    if not isinstance(keep, str) or len(keep) > 8000:
        raise ValueError('Must keep is too long.')
    target = {'Short': 'Aim for 70–110 words.', 'Balanced': 'Aim for 120–190 words.', 'Detailed': 'Aim for 190–280 words.'}[length]
    controls = f"\nWRITING CONTROLS: Mode: {mode}. Style preference: {style}. {target} These are soft length targets, not a word quota. In NEW IMAGE mode, add imaginative, relevant visual information instead of paraphrasing the input. In REFERENCE / EDIT mode, preserve the described source and limit additions to the requested change. Explicit brief instructions override a conflicting style selection. Must keep constraints are below; preserve them unless the latest refinement explicitly changes them.\nMust keep: {keep or '(none)'}"
    reference_image = check_reference(data)
    if reference_image:
        controls += ('\nA genuine reference image is attached in the next message. Base visual observations on the actual image. '
                     'Preserve visible identity, clothing, proportions, object count, framing, text and spatial relationships '
                     'unless explicitly instructed to edit them. Do not claim the picture is unavailable.')
        user_content = [{'type': 'text', 'text': brief},
                        {'type': 'image_url', 'image_url': {'url': reference_image}}]
    else:
        user_content = brief
    messages = [{'role': 'system', 'content': system + controls}, {'role': 'user', 'content': user_content}]
    if data.get('action', 'write') == 'refine':
        current, change = data.get('current', ''), data.get('change', '')
        if not all(isinstance(x, str) and x.strip() and len(x) <= 24000 for x in [current, change]):
            raise ValueError('Refine needs an existing prompt and your requested change (up to 24000 characters each).')
        messages.extend([{'role': 'assistant', 'content': current}, {'role': 'user', 'content': change}])
    elif data.get('action', 'write') != 'write':
        raise ValueError('Unknown action.')
    return {'model': model.strip(), 'messages': messages, 'stream': False,
            'temperature': temperature, 'max_tokens': tokens,
            'chat_template_kwargs': {'enable_thinking': False},
            'reasoning_effort': 'none'}

async def llama_cpp(method, path, data=None):
    """Use only the locally configured llama.cpp router; never accept a browser-supplied URL."""
    timeout = aiohttp.ClientTimeout(total=600 if path == '/v1/chat/completions' else 90)
    try:
        async with aiohttp.ClientSession(timeout=timeout, trust_env=False) as session:
            async with session.request(method, LLAMA_CPP_URL + path, json=data, allow_redirects=False) as response:
                raw = await response.text()
                try:
                    result = json.loads(raw)
                except ValueError:
                    raise WriterError(f'llama.cpp returned a non-JSON response (HTTP {response.status}).')
                if not isinstance(result, dict):
                    raise WriterError('llama.cpp returned an invalid response.')
                if response.status != 200 or result.get('error'):
                    err = result.get('error')
                    if isinstance(err, dict):
                        detail = err.get('message') or str(err)
                    elif err:
                        detail = str(err)
                    else:
                        detail = f'llama.cpp HTTP {response.status}'
                    if path.startswith('/models') and response.status == 404:
                        raise WriterError('llama.cpp router mode is required for model selection and automatic memory unloading. Start llama-server with --models-dir, without -m.')
                    raise WriterError(str(detail)[:1200])
                return result
    except asyncio.TimeoutError:
        raise WriterError('llama.cpp timed out. Try a smaller GGUF model or fewer output tokens.')
    except aiohttp.ClientError:
        raise WriterError('llama.cpp connection lost. Reopen the writer or press Refresh to restart it automatically.')

async def release_model(model):
    """The router stops the named model instance, releasing its model memory."""
    result = await llama_cpp('POST', '/models/unload', {'model': model})
    if result.get('success') is not True:
        raise WriterError('llama.cpp router did not confirm model unload.')
    return True

async def complete(request):
    result = await llama_cpp('POST', '/v1/chat/completions', request)
    choices = result.get('choices')
    if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
        raise WriterError('llama.cpp returned no prompt choices.')
    if choices[0].get('finish_reason') == 'length':
        raise WriterError('The response hit Max output tokens. Increase it and write again; the previous prompt is preserved.')
    message = choices[0].get('message')
    if not isinstance(message, dict):
        raise WriterError('llama.cpp returned an invalid message.')
    content = message.get('content', '')
    if not isinstance(content, str):
        raise WriterError('llama.cpp returned invalid prompt text.')
    return clean_output(content)

async def verify_vision_model(model_id):
    result = await llama_cpp('GET', '/models?reload=1')
    for info in result.get('data', []):
        if isinstance(info, dict) and info.get('id') == model_id:
            modalities = info.get('architecture', {}).get('input_modalities', [])
            return isinstance(modalities, list) and 'image' in modalities, info
    raise WriterError('The selected GGUF is not listed by llama.cpp. Press Refresh and select it again.')


def locate_router_model_file(model_id, info, settings):
    """Resolve a GGUF exposed by llama.cpp without making the user browse again.

    Router /models IDs are *names*, not guaranteed filesystem paths. Certain
    llama.cpp versions/third-party routers omit the GGUF path even for ordinary
    --models-dir files. Search only our known model directories and require an
    unambiguous exact filename match; never guess a different model/quant.
    """
    picked = chosen_model(settings)
    if picked is not None and chosen_model_id(picked) == model_id:
        return picked

    # First try the router's resolved path. Some builds omit it or return a
    # manifest instead of the actual model file. Loaded models sometimes expose
    # their original `-m` flag in status.args even if the top-level path is absent.
    hinted = []
    raw_path = info.get('path')
    if isinstance(raw_path, str):
        hinted.append(raw_path)
    status = info.get('status')
    args = status.get('args', []) if isinstance(status, dict) else []
    if isinstance(args, list):
        for i, arg in enumerate(args):
            if not isinstance(arg, str):
                continue
            if arg in ('-m', '--model') and i + 1 < len(args) and isinstance(args[i + 1], str):
                hinted.append(args[i + 1])
            elif arg.startswith('--model='):
                hinted.append(arg.split('=', 1)[1])
    for value in hinted:
        candidate = expanded_path(value)
        if (candidate.is_file() and candidate.suffix.casefold() == '.gguf'
                and not candidate.name.casefold().startswith('mmproj')):
            return candidate.resolve()

    # Only exact IDs / names are eligible. This avoids accidentally selecting
    # another quantization or a mmproj if multiple files share a folder.
    names = {model_id}
    display_name = info.get('name')
    if isinstance(display_name, str) and display_name:
        names.add(display_name)
    wanted = set()
    for name in names:
        for value in (name, name.rsplit('/', 1)[-1]):
            stem = value[:-5] if value.lower().endswith('.gguf') else value
            if stem and not any(c in stem for c in ('\\', '/', ':', '\r', '\n')):
                wanted.add(stem.casefold())
    if not wanted:
        return None

    roots = []
    try:
        configured = model_directory(settings)
    except WriterError:
        configured = None
    if configured is not None:
        roots.append(configured)
    home = Path.home()
    roots.extend((home / 'llama-models', home / 'llama.cpp' / 'models',
                  home / 'models' / 'GGUF', home / 'models',
                  home / 'Downloads' / 'GGUF'))
    if picked is not None:
        roots.insert(0, picked.parent)

    # The router supports one model folder of nesting for multimodal models.
    # Deliberately avoid recursive scans of arbitrary drives or entire caches.
    matches = set()
    visited = set()
    for root in roots:
        if not root.is_dir():
            continue
        try:
            normalized_root = root.resolve()
        except OSError:
            continue
        if normalized_root in visited:
            continue
        visited.add(normalized_root)
        try:
            entries = list(root.iterdir())
        except OSError:
            continue
        folders = [root] + [x for x in entries if x.is_dir()]
        for folder in folders:
            try:
                files = folder.iterdir()
                for item in files:
                    if item.is_file() and item.suffix.casefold() == '.gguf' and item.stem.casefold() in wanted:
                        matches.add(item.resolve())
            except OSError:
                continue
    return next(iter(matches)) if len(matches) == 1 else None


async def prepare_reference_vision(model_id):
    """The reference toggle is the ONLY vision toggle: configure and start it."""
    ready, info = await verify_vision_model(model_id)
    if ready:
        return
    path = await asyncio.to_thread(locate_router_model_file, model_id, info, user_settings())
    if path is None:
        raise WriterError('Reference image needs a local GGUF model, but the selected router did not provide its file path and no exact match was found in known model folders. '
                          'The Writer will not guess the wrong model.')
    outside_router = MANAGED_LLAMA is None or MANAGED_LLAMA.poll() is not None
    # Fetch only a pinned, verified vision dependency if absent.
    # Not a language model: the customer's existing GGUF stays unchanged.
    projector = await asyncio.to_thread(automatic_projector, path)
    global VISION_PRESET
    VISION_PRESET = (model_id, path, projector)
    # Server reads model presets on startup. Restart ONLY our own process.
    # If another program already owns 8080, start a separate private localhost
    # router rather than telling the customer to stop or reconfigure anything.
    global LLAMA_CPP_URL
    if outside_router:
        LLAMA_CPP_URL = free_loopback_endpoint()
    else:
        await asyncio.to_thread(stop_managed_llama)
    await ensure_llama_ready()
    ready, _ = await verify_vision_model(model_id)
    if not ready:
        raise WriterError('Gemma vision was configured automatically, but this llama.cpp build did not report image support. '
                          'Please update llama.cpp. No reference image was sent to a text-only model.')


async def generate(data):
    request = payload(data)
    review = data.get('review', True)
    if not isinstance(review, bool):
        raise ValueError('Review must be true or false.')
    # Reject oversized requests instead of silently losing early constraints.
    if sum(len(m['content']) if isinstance(m['content'], str) else sum(len(p.get('text', '')) for p in m['content'])
           for m in request['messages']) + request['max_tokens'] * 4 > 52000:
        raise ValueError('Shorten the brief or instructions to fit the context.')
    if data.get('reference_enabled', False):
        await prepare_reference_vision(request['model'])
    draft = await complete(request)
    if not review:
        return draft
    request['messages'].extend([
        {'role': 'assistant', 'content': draft},
        {'role': 'user', 'content': 'Polish this draft into the final Krea 2 image prompt. Check exact subject count, identities, props, handedness, framing, requested medium, literal quoted words, must-keep requirements and latest requested change. Fix contradictions, missed requirements, awkward descriptions and irrelevant clutter. IMPORTANT: In NEW IMAGE mode, preserve the imaginative supporting details, composition, textures and atmosphere that make the draft more useful than the original idea; improve weakly specified visuals when needed. Do NOT compress it into a paraphrase or delete fitting invented details merely because they were not in the brief. In REFERENCE / EDIT mode, do not add unrequested changes. Keep approximately the draft’s visual richness, while respecting the selected length and constraints. Return ONLY one natural-language paragraph with the final image prompt.'}
    ])
    request['temperature'] = min(request['temperature'], 0.35)
    return await complete(request)

def same_origin(request):
    origin = request.headers.get('Origin')
    return request.headers.get('Sec-Fetch-Site') != 'cross-site' and (not origin or urlsplit(origin).netloc == request.host)

@routes.get('/krea2-writer/config')
async def config(request):
    return web.json_response({'system': DEFAULT, 'version': '2.3.5'})

@routes.get('/krea2-writer/models')
async def models(request):
    if not same_origin(request):
        return web.json_response({'error': 'Cross-origin request blocked.'}, status=403)
    try:
        started = await ensure_llama_ready()
        result = await llama_cpp('GET', '/models?reload=1')
        names = sorted({m['id'] for m in result.get('data', []) if isinstance(m, dict) and isinstance(m.get('id'), str)})
        selected = chosen_model(user_settings())
        return web.json_response({'models': names, 'started': started,
                                  'selected_model': chosen_model_id(selected) if selected else None,
                                  'selected_filename': selected.name if selected else None})
    except WriterError as exc:
        return web.json_response({'error': str(exc)}, status=502)

@routes.post('/krea2-writer/browse-model')
async def browse_model(request):
    if not same_origin(request):
        return web.json_response({'error': 'Cross-origin request blocked.'}, status=403)
    if LOCK.locked() or BROWSE_LOCK.locked():
        return web.json_response({'error': 'Finish the current model operation before browsing.'}, status=409)
    try:
        async with BROWSE_LOCK:
            # Do not expose a path-based HTTP endpoint or upload gigantic models.
            # Only the user interacting with the server-side native dialog chooses a path.
            path = await asyncio.to_thread(native_gguf_picker)
            if path is None:
                return web.json_response({'cancelled': True})
            if path.suffix.casefold() != '.gguf' or not path.is_file():
                raise WriterError('Select an existing .gguf model file.')
            if LOCK.locked():
                raise WriterError('A prompt started while the file picker was open. Try Browse again.')
            selected = path.resolve()
            # A preexisting router is not ours to restart or reconfigure.
            router_status = await probe_router()
            if router_status == 'occupied':
                raise WriterError('Another service is using the llama.cpp port. Stop it before adding a model.')
            if router_status == 'ready' and (MANAGED_LLAMA is None or MANAGED_LLAMA.poll() is not None):
                raise WriterError('llama.cpp is running outside this Writer. Stop that external server first, then Browse again so the Writer can add your model.')
            async with LOCK:
                store_chosen_model(selected)
                # Router loads presets at startup. Restart ONLY a process that we own.
                if MANAGED_LLAMA is not None:
                    await asyncio.to_thread(stop_managed_llama)
                await ensure_llama_ready()
                result = await llama_cpp('GET', '/models?reload=1')
            names = sorted({m['id'] for m in result.get('data', []) if isinstance(m, dict) and isinstance(m.get('id'), str)})
            alias = chosen_model_id(selected)
            if alias not in names:
                raise WriterError('llama.cpp started, but did not list the selected GGUF preset. Check the llama-server.log for details.')
            return web.json_response({'models': names, 'selected_model': alias,
                                      'filename': selected.name})
    except WriterError as exc:
        return web.json_response({'error': str(exc)}, status=502)
    except OSError as exc:
        return web.json_response({'error': f'Could not save the model selection: {exc}'}, status=502)

@routes.post('/krea2-writer/write')
async def write(request):
    if not same_origin(request):
        return web.json_response({'error': 'Cross-origin request blocked.'}, status=403)
    if LOCK.locked():
        return web.json_response({'error': 'A prompt is already being written. Wait for it to finish.'}, status=409)
    try:
        async with LOCK:
            data = await request.json()
            # Router keeps the selected GGUF loaded during both passes;
            # explicit unload in finally releases its memory after completion or failure.
            model_name = payload(data)['model']
            await ensure_llama_ready()
            release_confirmed = False
            release_warning = None
            try:
                result = await generate(data)
            finally:
                try:
                    release_confirmed = await release_model(model_name)
                except (WriterError, aiohttp.ClientError, asyncio.TimeoutError) as exc:
                    # Preserve a completed prompt but report any release failure honestly.
                    release_warning = 'llama.cpp unload failed: ' + str(exc)
            return web.json_response({'prompt': result, 'model_unloaded': release_confirmed,
                                      'unload_warning': release_warning})
    except (ValueError, TypeError, OverflowError):
        return web.json_response({'error': 'Invalid input. Check the brief, model, settings and refinement text.'}, status=400)
    except WriterError as exc:
        return web.json_response({'error': str(exc)}, status=502)

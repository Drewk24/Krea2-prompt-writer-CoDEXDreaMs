# Krea 2 Prompt Writer v2.3.5 — llama.cpp AUTO-START + MODEL BROWSE + REFERENCE IMAGE

A free, unofficial ComfyUI prompt-writing extension using **already installed local llama.cpp**.

Based directly on the working v2.2.1 Button Fix, retaining the green floating button and compact two-column interface.

## Installation (Windows / ComfyUI Desktop)

1. **Close ComfyUI first.** Extract the ZIP and run `INSTALL.cmd`. Select your own ComfyUI folder (containing `main.py` and `custom_nodes`) if asked. The installer backs up any existing Prompt Writer.
2. Have `llama-server.exe` installed on your computer. You install llama.cpp and your chosen GGUF model yourself; **this package downloads neither**.
3. Restart ComfyUI Desktop, press `Ctrl+F5`, and click the floating **Krea 2 Writer** button. **The Writer automatically locates and starts llama.cpp in the background**, then lists your available GGUF models. No terminal, manual command, or persistent PowerShell window needed.
4. If your GGUF isn't in the dropdown, click the small **📁 folder icon** beside the model selector. Pick the existing `.gguf` file in Windows' native file picker; the Writer saves its location, restarts only its own background llama.cpp server when needed, and selects it for you. **No model weights are uploaded, copied, moved, or downloaded.** If a separate external llama.cpp router is already running on the same port, close it before browsing so the Writer can register the model.
5. Select your own GGUF, enter a description, and click **Write prompt** (or Refine). The Writer unloads the selected model afterward to free its RAM/VRAM.

The server is started **only when you open the Prompt Writer or request a prompt**—not when ComfyUI first launches. Already-running compatible local llama.cpp router servers are reused, not replaced or shut down. When ComfyUI closes cleanly, the Writer stops only a server it launched itself.

## Automatic discovery

The Writer checks for `llama-server.exe` on Windows PATH, then typical user-local llama.cpp release/build folders (including `%USERPROFILE%\llama.cpp`). It looks for `.gguf` files in `%USERPROFILE%\llama-models`, `%USERPROFILE%\llama.cpp\models`, `%USERPROFILE%\models\GGUF`, and a few other standard folders. If none is found, llama.cpp's existing **model cache** is available as a fallback.

If your llama.cpp or GGUF folder is somewhere unusual, configure it once by creating:

`%LOCALAPPDATA%\Krea2PromptWriter\settings.json`

Example (edit both paths for your own PC):

```json
{
  "llama_server_exe": "C:\\YourFolder\\llama.cpp\\llama-server.exe",
  "models_dir": "D:\\YourModels\\GGUF"
}
```

Only the paths you need are required. You do **not** need to edit this file for unusual GGUF locations when you can use the **📁 Browse** icon; it uses a llama.cpp model preset that points directly at your chosen file. For multi-shard/multimodal GGUFs, keep companion files together as required by llama.cpp.

An alternative is setting `KREA2_LLAMA_SERVER_EXE` and `KREA2_LLAMA_MODELS_DIR` for the ComfyUI process. The localhost endpoint defaults to `http://127.0.0.1:8080`; it can be changed with `KREA2_LLAMA_CPP_URL` before launching ComfyUI. **Auto-start only supports local loopback, not remote servers.**

Logs for an automatically launched server are written to `%LOCALAPPDATA%\Krea2PromptWriter\llama-server.log`. Any startup failure should show its cause and the log path inside the Writer.

## How it works

- User opens the Writer: ComfyUI backend checks for a compatible local llama.cpp **router**.
- If the router is not running, it starts the customer's installed `llama-server.exe` invisibly with `--models-max 1` and (when detected) `--models-dir`, plus `-ngl 99` and `-c 8192`.
- The Browse action opens a native file dialog on the ComfyUI server PC, writes only the chosen path into a local settings file, and adds that model using `--models-preset` without copying its weights.
- If port 8080 is already used by another service or a llama.cpp single-model server, it gives an error instead of launching over it.
- Prompts are sent to `/v1/chat/completions`; finished or failed writes request `/models/unload` to free memory.
- Reference images are sent directly to the local llama.cpp vision endpoint when the reference option is selected.

This release keeps the existing write, refine, 2-pass review, copy, style, length, reference/edit, Must keep, saved draft and custom instructions features.

No executable files, model weights, or Ollama are bundled. A verified Gemma 4 projector is fetched automatically only if needed for enabled reference images. Not affiliated with Krea.ai, ComfyUI, Google or ggml-org; users remain responsible for the licenses of their chosen models.

## Reference images

The Writer has **Enable Reference Image?** beneath the brief. It is **off by default**. Turn it on to display the drop area and Browse image button. Choose a local PNG, JPEG, or WebP, or drag it into the box. The image preview can be removed. The browser converts the image to a locally encoded JPEG (max edge 1600px); it is sent only to the local ComfyUI Writer backend and the user's local llama.cpp API. The image is kept only in current browser memory and is not saved in settings, drafts, or the GGUF model directory. Text-only mode does not send an image even if one is selected.

**Reference-image vision is now automatic.** When the user turns on **Enable Reference Image?** and clicks Write, the Writer checks for existing image support. If the selected local Gemma 4 12B model lacks its matching projector, it looks for a projector already installed. If missing, the Writer silently fetches the **verified Unsloth vision companion (~175 MB, one time)** into its own local cache, checks its SHA-256, configures llama.cpp, and restarts **only its own** background router before sending the image. **No second Enable Vision button, no manual mmproj download or placement, no PowerShell.** The main model GGUF and llama.cpp remain customer-provided; the Writer never downloads language models or executables. This automatic one-time network download occurs only when the reference option is enabled and a matching projector is missing. The attached image itself is sent only to the local ComfyUI/llama.cpp service, not the internet.

Models already registered as vision-capable are used as-is. If a model is not vision-capable and is not one of the supported automatic-projector families, the Writer stops rather than fabricate image analysis. A separately started external server is never terminated or reconfigured: if it lacks image support, the Writer starts its own secondary local router automatically. Windows/GPU validation is still required before production publishing.

## v2.3.5: model detection fix

When the selected llama.cpp router exposes only a model *ID* (for example,
`gemma-4-12b-it-Q4_K_M`) instead of an absolute GGUF path, the Writer now
finds that exact file automatically within recognized model folders and their
one-level subfolders. It also honors a path advertised by llama.cpp itself.
Once found, the existing **Enable Reference Image?** checkbox triggers
projector setup (if required) and vision-capable startup by itself.
There is no additional button or browse step for models in those folders.
If multiple different files have an identical model filename, the Writer
intentionally refuses to guess which file is correct.

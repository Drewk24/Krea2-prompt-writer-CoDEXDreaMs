"""Optional isolated Chromium UI test; no web/network required."""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
JS = (ROOT/'web/writer.js').read_text(encoding='utf-8')
JS = JS.replace("import { app } from '../../scripts/app.js';", '')
JS = JS.replace("import { api } from '../../scripts/api.js';", '')
JS = JS.replace("new URL('./writer.css', import.meta.url).href", "'/extensions/krea/writer.css'")
CSS = (ROOT/'web/writer.css').read_text(encoding='utf-8')
SYSTEM = (ROOT/'prompts/writer_v2.txt').read_text(encoding='utf-8')
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--no-proxy-server'])
    try:
        page = browser.new_page(viewport={'width':1024,'height':768})
        page.set_default_timeout(3500)
        errors=[]
        page.on('pageerror', lambda exc: errors.append(str(exc)))
        page.set_content('<html><head></head><body></body></html>')
        page.add_style_tag(content=CSS)
        page.evaluate("""(system) => {
            Object.defineProperty(window,'localStorage',{value:{getItem(){return null},setItem(){}},configurable:true});
            window.__calls=[];
            window.__app={registerExtension(e){e.setup()}};
            window.__api={fetchApi:async(path, opts)=>{
                if (path.endsWith('/config')) return new Response(JSON.stringify({system}),{status:200});
                if (path.endsWith('/models')) return new Response(JSON.stringify({models:['gemma-detected.gguf']}),{status:200});
                if (path.endsWith('/browse-model')) return new Response(JSON.stringify({models:['gemma-detected.gguf','krea2-picked-123abc'],selected_model:'krea2-picked-123abc',filename:'gemma-4-Q4.gguf'}),{status:200});
                if (path.endsWith('/write')) {
                    const payload=JSON.parse(opts.body);
                    window.__calls.push(payload);
                    return new Response(JSON.stringify({prompt:'A detailed photorealistic sunset over the mountain lake.',model_unloaded:true}),{status:200});
                }
                return new Response('{}',{status:404});
            }};
        }""", SYSTEM)
        page.add_script_tag(content='const app=window.__app, api=window.__api;\n' + JS)
        page.locator('#krea2-writer-launcher').click(timeout=3000)
        page.get_by_text('1 models ready.', exact=False).wait_for()
        icon=page.get_by_role('button', name='Browse for GGUF model')
        assert icon.is_visible()
        assert icon.evaluate('(button) => button.parentElement.querySelector("select") !== null')
        icon.click()
        page.get_by_text('Selected gemma-4-Q4.gguf.', exact=False).wait_for()
        assert page.get_by_label('llama.cpp model').input_value()=='krea2-picked-123abc'
        assert page.get_by_label('llama.cpp model').locator('option:checked').inner_text()=='📁 gemma-4-Q4.gguf'
        page.get_by_label('Describe your image').fill('A lake at sunset')
        page.get_by_role('button', name='✦ Write prompt').click()
        page.get_by_text('Prompt ready',exact=False).wait_for()
        assert page.evaluate('window.__calls[0].model') == 'krea2-picked-123abc'
        assert 'mountain lake' in page.get_by_label('Your Krea prompt — editable').input_value()
        page.screenshot(path='/mnt/data/krea_browse_ui_1024.png')
        assert not errors,errors
        print('PASS: Chromium 1024x768 icon placement, browser select, saved model value, write prompt, no JS errors')
    finally:browser.close()

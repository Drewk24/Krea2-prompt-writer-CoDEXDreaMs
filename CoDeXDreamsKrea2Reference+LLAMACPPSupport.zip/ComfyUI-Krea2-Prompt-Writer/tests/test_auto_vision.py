"""Tests for one-switch reference image vision activation; no network/llama GPU used."""
import asyncio
import hashlib
import io
import importlib.util
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, Mock, patch
from aiohttp import web

ROOT = Path(__file__).resolve().parents[1]
prior_server = sys.modules.get('server')
sys.modules['server'] = types.SimpleNamespace(PromptServer=types.SimpleNamespace(instance=types.SimpleNamespace(routes=web.RouteTableDef())))
spec=importlib.util.spec_from_file_location('vision_writer_backend',ROOT/'backend.py')
b=importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)
if prior_server is None: sys.modules.pop('server', None)
else: sys.modules['server'] = prior_server

class LocalResponse:
    def __init__(self, data): self.data=io.BytesIO(data)
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, n): return self.data.read(n)
    def geturl(self): return 'https://cas-bridge.xethub.hf.co/mock'

class AutoVisionTests(unittest.IsolatedAsyncioTestCase):
    async def test_auto_download_verified_companion_and_cache(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td)
            model=folder/'gemma-4-12b-it-Q4_K_M.gguf';model.write_bytes(b'model')
            fake=b'G'*(1024*1024+100)
            with patch.object(b,'settings_path',return_value=folder/'settings.json'),\
                 patch.object(b,'GEMMA4_MMPROJ_SHA256',hashlib.sha256(fake).hexdigest()),\
                 patch.object(b.urllib.request,'urlopen',return_value=LocalResponse(fake)) as request:
                projector=b.automatic_projector(model)
                self.assertEqual(projector.read_bytes(),fake)
                self.assertEqual(projector,b.automatic_projector(model))
                self.assertEqual(request.call_count,1)
                self.assertFalse(projector.with_suffix('.gguf.part').exists())

    async def test_auto_download_rejects_corruption(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td)
            model=folder/'gemma-4-12b-it-Q4_K_M.gguf';model.write_bytes(b'model')
            fake=b'bad vision bytes'
            with patch.object(b,'settings_path',return_value=folder/'settings.json'),\
                 patch.object(b.urllib.request,'urlopen',return_value=LocalResponse(fake)):
                with self.assertRaisesRegex(b.WriterError,'checksum'):
                    b.automatic_projector(model)
                self.assertEqual(list((folder/'vision').rglob('*.gguf')),[])
                self.assertEqual(list((folder/'vision').rglob('*.part')),[])

    async def test_auto_download_rejects_wrong_model(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td)
            model=folder/'random-text-7b.gguf';model.write_bytes(b'model')
            with patch.object(b,'settings_path',return_value=folder/'settings.json'),\
                 patch.object(b.urllib.request,'urlopen') as network:
                with self.assertRaisesRegex(b.WriterError,'multimodal'):
                    b.automatic_projector(model)
                network.assert_not_called()

    async def test_toggle_prepares_vision_and_restarts_only_managed_router(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td);model=folder/'gemma-4-12b-it-Q4_K_M.gguf';model.write_bytes(b'M')
            proj=folder/'mmproj-F16.gguf';proj.write_bytes(b'P')
            pretend_managed=Mock();pretend_managed.poll.return_value=None
            original=b.VISION_PRESET
            try:
                b.VISION_PRESET=None
                with patch.object(b,'chosen_model',return_value=model),\
                     patch.object(b,'chosen_model_id',return_value='gemma4'),\
                     patch.object(b,'user_settings',return_value={'selected_model':str(model)}),\
                     patch.object(b,'MANAGED_LLAMA',pretend_managed),\
                     patch.object(b,'verify_vision_model',new_callable=AsyncMock,side_effect=[(False, {'id':'gemma4'}),(True, {'id':'gemma4'})]) as check,\
                     patch.object(b,'automatic_projector',return_value=proj) as fetch,\
                     patch.object(b,'stop_managed_llama') as stop,\
                     patch.object(b,'ensure_llama_ready',new_callable=AsyncMock) as start:
                    await b.prepare_reference_vision('gemma4')
                    self.assertEqual(b.VISION_PRESET,('gemma4',model,proj))
                    check.assert_awaited()
                    fetch.assert_called_once_with(model)
                    stop.assert_called_once()
                    start.assert_awaited_once()
            finally: b.VISION_PRESET=original

    async def test_external_router_uses_private_port_without_stopping_it(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td); model=folder/'gemma-4-12b-it-Q4_K_M.gguf'; model.write_bytes(b'M')
            proj=folder/'mmproj-F16.gguf'; proj.write_bytes(b'P')
            old_preset, old_url=b.VISION_PRESET,b.LLAMA_CPP_URL
            try:
                b.VISION_PRESET=None
                b.LLAMA_CPP_URL='http://127.0.0.1:8080'
                with patch.object(b,'chosen_model',return_value=model),\
                     patch.object(b,'chosen_model_id',return_value='gemma4'),\
                     patch.object(b,'user_settings',return_value={'selected_model':str(model)}),\
                     patch.object(b,'MANAGED_LLAMA',None),\
                     patch.object(b,'verify_vision_model',new_callable=AsyncMock,side_effect=[(False, {'id':'gemma4'}),(True, {'id':'gemma4'})]),\
                     patch.object(b,'automatic_projector',return_value=proj),\
                     patch.object(b,'free_loopback_endpoint',return_value='http://127.0.0.1:34567'),\
                     patch.object(b,'stop_managed_llama') as stop,\
                     patch.object(b,'ensure_llama_ready',new_callable=AsyncMock) as start:
                    await b.prepare_reference_vision('gemma4')
                    self.assertEqual(b.LLAMA_CPP_URL,'http://127.0.0.1:34567')
                    stop.assert_not_called()
                    start.assert_awaited_once()
            finally:
                b.VISION_PRESET, b.LLAMA_CPP_URL=old_preset,old_url

    async def test_router_id_resolves_model_in_flat_models_dir(self):
        # Screenshot failure: router reports ID but omits path/image metadata.
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            model=root/'gemma-4-12b-it-Q4_K_M.gguf';model.write_bytes(b'M')
            with patch.object(b,'model_directory',return_value=root),\
                 patch.object(b,'chosen_model',return_value=None),\
                 patch.object(b.Path,'home',return_value=root / 'not-a-user-folder'):
                found=b.locate_router_model_file('gemma-4-12b-it-Q4_K_M',
                    {'id':'gemma-4-12b-it-Q4_K_M','architecture':{'input_modalities':['text']}}, {})
                self.assertEqual(found,model.resolve())

    async def test_router_id_resolves_nested_gguf_and_ignores_other_quant(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            folder=root/'gemma-4-12b-it-Q4_K_M';folder.mkdir()
            model=folder/'gemma-4-12b-it-Q4_K_M.gguf';model.write_bytes(b'M')
            (root/'gemma-4-12b-it-Q8_0.gguf').write_bytes(b'NOT THE CHOSEN MODEL')
            (root/'mmproj-F16.gguf').write_bytes(b'P')
            with patch.object(b,'model_directory',return_value=root),\
                 patch.object(b,'chosen_model',return_value=None),\
                 patch.object(b.Path,'home',return_value=root/'not-a-user-folder'):
                found=b.locate_router_model_file('gemma-4-12b-it-Q4_K_M',
                    {'id':'gemma-4-12b-it-Q4_K_M','path':'/not/a/gguf'}, {})
                self.assertEqual(found,model.resolve())

    async def test_router_status_args_path_when_model_is_on_an_unusual_drive(self):
        with tempfile.TemporaryDirectory() as td:
            model=Path(td)/'gemma-4-12b-it-Q4_K_M.gguf';model.write_bytes(b'M')
            with patch.object(b,'chosen_model',return_value=None),\
                 patch.object(b,'model_directory',return_value=None):
                self.assertEqual(b.locate_router_model_file('gemma-4-12b-it-Q4_K_M',
                    {'id':'gemma-4-12b-it-Q4_K_M','status':{'args':['llama-server','-m',str(model)]}}, {}),model.resolve())

    async def test_router_id_duplicate_is_not_guessed(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            model=root/'gemma-4-12b-it-Q4_K_M.gguf';model.write_bytes(b'M')
            folder=root/'a-second-copy';folder.mkdir()
            (folder/model.name).write_bytes(b'OTHER MODEL')
            with patch.object(b,'model_directory',return_value=root),\
                 patch.object(b,'chosen_model',return_value=None),\
                 patch.object(b.Path,'home',return_value=root/'not-a-user-folder'):
                self.assertIsNone(b.locate_router_model_file('gemma-4-12b-it-Q4_K_M',{'id':'gemma-4-12b-it-Q4_K_M'},{}))

    async def test_reference_toggle_fixes_router_id_missing_gguf_path(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td);model=folder/'gemma-4-12b-it-Q4_K_M.gguf';model.write_bytes(b'M')
            proj=folder/'mmproj-F16.gguf';proj.write_bytes(b'P')
            old_preset,old_url=b.VISION_PRESET,b.LLAMA_CPP_URL
            try:
                b.VISION_PRESET=None
                b.LLAMA_CPP_URL='http://127.0.0.1:8080'
                with patch.object(b,'model_directory',return_value=folder),\
                     patch.object(b,'chosen_model',return_value=None),\
                     patch.object(b.Path,'home',return_value=folder/'not-a-user-folder'),\
                     patch.object(b,'user_settings',return_value={}),\
                     patch.object(b,'MANAGED_LLAMA',None),\
                     patch.object(b,'verify_vision_model',new_callable=AsyncMock,side_effect=[
                        (False, {'id':'gemma-4-12b-it-Q4_K_M','architecture':{'input_modalities':['text']}}),
                        (True, {'id':'gemma-4-12b-it-Q4_K_M','architecture':{'input_modalities':['text','image']}})]),\
                     patch.object(b,'automatic_projector',return_value=proj) as project,\
                     patch.object(b,'free_loopback_endpoint',return_value='http://127.0.0.1:35559'),\
                     patch.object(b,'stop_managed_llama') as stop,\
                     patch.object(b,'ensure_llama_ready',new_callable=AsyncMock) as start:
                    await b.prepare_reference_vision('gemma-4-12b-it-Q4_K_M')
                    self.assertEqual(b.VISION_PRESET,('gemma-4-12b-it-Q4_K_M',model.resolve(),proj))
                    project.assert_called_once_with(model.resolve())
                    stop.assert_not_called()
                    start.assert_awaited_once()
            finally:
                b.VISION_PRESET,b.LLAMA_CPP_URL=old_preset,old_url

    async def test_already_vision_capable_never_downloads_or_restarts(self):
        with patch.object(b,'verify_vision_model',new_callable=AsyncMock,return_value=(True,{})),\
             patch.object(b,'automatic_projector') as get,\
             patch.object(b,'stop_managed_llama') as stop:
            await b.prepare_reference_vision('already-vision')
            get.assert_not_called();stop.assert_not_called()

    async def test_off_toggle_uses_text_and_no_vision(self):
        with patch.object(b,'prepare_reference_vision',new_callable=AsyncMock) as configure,\
             patch.object(b,'complete',new_callable=AsyncMock,return_value='Done'):
            result=await b.generate({'model':'gemma:12b','brief':'A castle','review':False,'reference_enabled':False})
            self.assertEqual(result,'Done')
            configure.assert_not_awaited()

if __name__ == '__main__': unittest.main()

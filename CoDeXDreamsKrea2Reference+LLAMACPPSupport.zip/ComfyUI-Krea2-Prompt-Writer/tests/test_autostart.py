"""Integration tests for invisible on-demand llama.cpp launcher using a fake router process."""
import asyncio
import importlib.util
import json
import os
import socket
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

ROOT = Path(__file__).resolve().parents[1]
if 'server' not in sys.modules:
    sys.modules['server'] = types.SimpleNamespace(PromptServer=types.SimpleNamespace(instance=types.SimpleNamespace(routes=web.RouteTableDef())))
spec = importlib.util.spec_from_file_location('writer_autostart_backend', ROOT / 'backend.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

MOCK_SERVER = r'''#!/usr/bin/env python3
import argparse, json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
p=argparse.ArgumentParser(add_help=False)
p.add_argument('--port', type=int, required=True); p.add_argument('--host');p.add_argument('--models-dir');p.add_argument('--models-max');p.add_argument('--models-preset');p.add_argument('-c');p.add_argument('-ngl')
a=p.parse_args()
class Server(BaseHTTPRequestHandler):
    def log_message(self, *_): pass
    def reply(self, payload):
        data=json.dumps(payload).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
    def do_GET(self):
        if self.path.startswith('/models'):
            names=['fake-gemma4.gguf']
            if a.models_preset:
                for line in open(a.models_preset, encoding='utf-8'):
                    line=line.strip()
                    if line.startswith('[krea2-picked-') and line.endswith(']'):
                        names.append(line[1:-1])
            self.reply({'data':[{'id':name} for name in names]});return
        self.send_error(404)
    def do_POST(self):
        length=int(self.headers.get('Content-Length',0));body=json.loads(self.rfile.read(length) or '{}')
        if self.path == '/v1/chat/completions':
            self.reply({'choices':[{'finish_reason':'stop','message':{'content':'A clean rendered image prompt.'}}]});return
        if self.path == '/models/unload':
            self.reply({'success':True});return
        self.send_error(404)
ThreadingHTTPServer(('127.0.0.1',a.port),Server).serve_forever()
'''


def unused_port():
    with socket.socket() as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


class AutoStartTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='krea-autostart-')
        root = Path(self.temp.name)
        self.binary = root / 'llama-server'
        self.binary.write_text(MOCK_SERVER)
        self.binary.chmod(0o755)
        self.models = root / 'gguf'
        self.models.mkdir()
        (self.models / 'fake-gemma4.gguf').write_bytes(b'fake GGUF for test')
        self.port = unused_port()
        b.LLAMA_CPP_URL = f'http://127.0.0.1:{self.port}'
        b.MANAGED_LLAMA = None
        b.LAUNCH_LOG = None
        b.START_LOCK = asyncio.Lock()
        b.LOCK = asyncio.Lock()
        b.settings_path = lambda: root / 'settings.json'
        self.app = web.Application()
        self.app.add_routes(b.routes)
        self.client = TestClient(TestServer(self.app))
        await self.client.start_server()
        self.exe_patch = patch.object(b, 'server_executable', return_value=self.binary)
        self.model_patch = patch.object(b, 'model_directory', return_value=self.models)
        self.exe_patch.start(); self.model_patch.start()

    async def asyncTearDown(self):
        await self.client.close()
        b.stop_managed_llama()
        await asyncio.sleep(.1)
        self.exe_patch.stop(); self.model_patch.stop()
        self.temp.cleanup()

    async def test_native_browse_adds_arbitrary_gguf_outside_models_folder(self):
        foreign = Path(self.temp.name) / 'other models' / 'Gemma 4 Q4.gguf'
        foreign.parent.mkdir(parents=True)
        foreign.write_bytes(b'local GGUF stays here')
        with patch.object(b, 'native_gguf_picker', return_value=foreign):
            response = await self.client.post('/krea2-writer/browse-model', json={'path': '/forged/path.gguf'})
        self.assertEqual(response.status, 200, await response.text())
        data = await response.json()
        self.assertEqual(data['filename'], foreign.name)
        self.assertIn(data['selected_model'], data['models'])
        self.assertTrue(foreign.exists())
        self.assertEqual(json.loads(b.settings_path().read_text())['selected_model'], str(foreign))
        self.assertIn(str(foreign), (b.settings_path().parent / 'selected-model.ini').read_text())
        response = await self.client.post('/krea2-writer/write', json={
            'model': data['selected_model'], 'brief': 'A cat', 'review': False})
        self.assertEqual(response.status, 200, await response.text())
        self.assertTrue((await response.json())['model_unloaded'])
        response = await self.client.get('/krea2-writer/models')
        self.assertEqual((await response.json())['selected_model'], data['selected_model'])

    async def test_browse_cancel_preserves_running_router_and_settings(self):
        await b.ensure_llama_ready()
        proc = b.MANAGED_LLAMA
        with patch.object(b, 'native_gguf_picker', return_value=None):
            response = await self.client.post('/krea2-writer/browse-model', json={})
        self.assertEqual((await response.json())['cancelled'], True)
        self.assertEqual(proc.pid, b.MANAGED_LLAMA.pid)
        self.assertFalse(b.settings_path().exists())

    async def test_browse_rejects_non_gguf_file(self):
        file = Path(self.temp.name) / 'not-a-model.txt'
        file.write_text('hello')
        with patch.object(b, 'native_gguf_picker', return_value=file):
            response = await self.client.post('/krea2-writer/browse-model', json={})
        self.assertEqual(response.status, 502)
        self.assertIn('.gguf', (await response.json())['error'])

    async def test_browse_does_not_restart_external_router(self):
        await b.ensure_llama_ready()
        proc = b.MANAGED_LLAMA
        b.MANAGED_LLAMA = None
        file = Path(self.temp.name) / 'other.gguf'
        file.write_bytes(b'fake')
        try:
            with patch.object(b, 'native_gguf_picker', return_value=file):
                response = await self.client.post('/krea2-writer/browse-model', json={})
            self.assertEqual(response.status, 502)
            self.assertIn('Stop that external server', (await response.json())['error'])
            self.assertIsNone(b.MANAGED_LLAMA)
        finally:
            proc.terminate()
            await asyncio.to_thread(proc.wait, 5)

    async def test_starts_on_open_and_generates_and_unloads(self):
        self.assertIsNone(b.MANAGED_LLAMA)
        response = await self.client.get('/krea2-writer/models')
        self.assertEqual(response.status, 200)
        self.assertEqual(await response.json(), {'models':['fake-gemma4.gguf'], 'started':True, 'selected_model':None, 'selected_filename':None})
        self.assertIsNotNone(b.MANAGED_LLAMA)
        self.assertIsNone(b.MANAGED_LLAMA.poll())
        pid = b.MANAGED_LLAMA.pid
        response = await self.client.post('/krea2-writer/write', json={'model':'fake-gemma4.gguf','brief':'an alley at night','review':True})
        self.assertEqual(response.status,200)
        self.assertEqual((await response.json())['model_unloaded'],True)
        response = await self.client.get('/krea2-writer/models')
        self.assertEqual((await response.json())['started'],False)
        self.assertEqual(pid, b.MANAGED_LLAMA.pid)

    async def test_launch_works_from_write_without_refresh(self):
        response = await self.client.post('/krea2-writer/write', json={'model':'fake-gemma4.gguf','brief':'a cat','review':False})
        self.assertEqual(response.status,200)
        self.assertTrue((await response.json())['model_unloaded'])

    async def test_concurrent_requests_launch_only_once(self):
        a, c = await asyncio.gather(b.ensure_llama_ready(), b.ensure_llama_ready())
        self.assertCountEqual([a,c], [True,False])

    async def test_external_router_reused_and_not_killed(self):
        self.assertTrue(await b.ensure_llama_ready())
        proc = b.MANAGED_LLAMA
        b.MANAGED_LLAMA = None
        self.assertFalse(await b.ensure_llama_ready())
        self.assertIsNone(b.MANAGED_LLAMA)
        b.stop_managed_llama()
        self.assertIsNone(proc.poll())
        proc.terminate()
        await asyncio.to_thread(proc.wait, 5)

    async def test_recovers_after_server_exits(self):
        self.assertTrue(await b.ensure_llama_ready())
        old=b.MANAGED_LLAMA
        old.terminate()
        await asyncio.to_thread(old.wait, 5)
        self.assertTrue(await b.ensure_llama_ready())
        self.assertNotEqual(old.pid, b.MANAGED_LLAMA.pid)

    async def test_occupied_port_does_not_spawn(self):
        async def occupied(_):
            return web.Response(text='<html>Other server</html>')
        # Use a separate existing HTTP server at our configured port.
        dummy = web.Application(); dummy.router.add_get('/models', occupied)
        upstream = TestServer(dummy, host='127.0.0.1', port=self.port)
        await upstream.start_server()
        try:
            response=await self.client.get('/krea2-writer/models')
            self.assertEqual(response.status,502)
            self.assertIn('another service', (await response.json())['error'])
            self.assertIsNone(b.MANAGED_LLAMA)
        finally:
            await upstream.close()

    async def test_custom_paths_validated_and_no_unrequested_downloads(self):
        self.exe_patch.stop();self.model_patch.stop()
        # No implicit download process; only local executable / model directory.
        cfg=Path(self.temp.name) / 'settings.json'
        cfg.write_text(json.dumps({'llama_server_exe':str(self.binary),'models_dir':str(self.models)}))
        self.assertEqual(b.server_executable(b.user_settings()),self.binary)
        self.assertEqual(b.model_directory(b.user_settings()),self.models)
        cfg.write_text(json.dumps({'models_dir':str(Path(self.temp.name) / 'missing')}))
        with self.assertRaises(b.WriterError):b.model_directory(b.user_settings())
        self.exe_patch.start();self.model_patch.start()

    async def test_nonlocal_startup_rejected(self):
        b.LLAMA_CPP_URL = 'https://example.com:8080'
        with self.assertRaises(b.WriterError):b.local_port()

if __name__ == '__main__':
    unittest.main(verbosity=2)

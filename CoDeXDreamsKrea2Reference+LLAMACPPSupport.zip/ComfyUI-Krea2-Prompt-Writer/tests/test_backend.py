import asyncio
import base64
import io
import importlib.util
import sys
import types
import unittest
from pathlib import Path
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

ROOT = Path(__file__).resolve().parents[1]
routes = web.RouteTableDef()
sys.modules['server'] = types.SimpleNamespace(PromptServer=types.SimpleNamespace(instance=types.SimpleNamespace(routes=routes)))
spec = importlib.util.spec_from_file_location('writer_backend', ROOT / 'backend.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

class BackendTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.calls = []
        self.unloads = []
        self.fail_unload = False
        self.mode = 'ok'
        self.no_router = False
        async def chat(request):
            data = await request.json(); self.calls.append(data)
            if self.mode == 'missing':
                return web.json_response({'error': {'message': 'model not found'}}, status=404)
            if self.mode == 'empty':
                return web.json_response({'choices': [{'message': {'content': ''}, 'finish_reason': 'stop'}]})
            if self.mode == 'length':
                return web.json_response({'choices': [{'message': {'content': 'partial'}, 'finish_reason': 'length'}]})
            return web.json_response({'choices': [{'message': {'content': '<think>hidden</think>A painted red boat on a quiet lake.'}, 'finish_reason': 'stop'}]})
        async def unload(request):
            data = await request.json(); self.unloads.append(data)
            if self.no_router: return web.json_response({'error': {'message':'not found'}}, status=404)
            if self.fail_unload: return web.json_response({'error': {'message': 'could not unload'}}, status=503)
            return web.json_response({'success': True})
        async def models(request):
            if self.no_router: return web.json_response({'error': {'message':'not found'}}, status=404)
            return web.json_response({'data': [{'id': 'custom/model:Q4', 'architecture': {'input_modalities':['text','image']}}, {'id': 'gemma:test', 'architecture': {'input_modalities':['text']}}, {'id': 20}, None]})
        mock = web.Application()
        mock.router.add_post('/v1/chat/completions', chat)
        mock.router.add_post('/models/unload', unload)
        mock.router.add_get('/models', models)
        self.llama = TestServer(mock); await self.llama.start_server()
        b.LLAMA_CPP_URL = str(self.llama.make_url('')).rstrip('/')
        b.LOCK = asyncio.Lock()
        app = web.Application(); app.add_routes(routes)
        self.client = TestClient(TestServer(app)); await self.client.start_server()
    async def asyncTearDown(self):
        await self.client.close(); await self.llama.close()
    async def send(self, **extra):
        return await self.client.post('/krea2-writer/write', json={'model': 'custom/model:Q4', 'brief': 'A painted red boat.', 'review': False, **extra})
    async def test_config_and_models(self):
        r=await self.client.get('/krea2-writer/config')
        self.assertEqual((await r.json())['version'],'2.3.5')
        self.assertEqual((await r.json())['system'],b.DEFAULT)
        r=await self.client.get('/krea2-writer/models')
        self.assertEqual((await r.json())['models'],['custom/model:Q4','gemma:test'])
    async def test_write_and_unload(self):
        r=await self.send(); self.assertEqual(r.status,200)
        data=await r.json()
        self.assertEqual(data['prompt'],'A painted red boat on a quiet lake.')
        self.assertTrue(data['model_unloaded'])
        self.assertEqual(self.unloads,[{'model':'custom/model:Q4'}])
        self.assertEqual(self.calls[0]['model'],'custom/model:Q4')
        self.assertFalse(self.calls[0]['stream'])
        self.assertEqual(self.calls[0]['max_tokens'],1536)
        self.assertEqual(self.calls[0]['temperature'],.7)
        self.assertEqual(self.calls[0]['chat_template_kwargs'],{'enable_thinking':False})
        self.assertEqual(self.calls[0]['reasoning_effort'],'none')
    async def test_refine_and_custom_system(self):
        r=await self.send(action='refine',current='A red boat.',change='Make it blue.',system='Custom instructions',unload=False)
        self.assertEqual(r.status,200)
        self.assertEqual([m['role'] for m in self.calls[0]['messages']],['system','user','assistant','user'])
        self.assertEqual(self.unloads,[{'model':'custom/model:Q4'}])
        self.assertTrue(self.calls[0]['messages'][0]['content'].startswith('Custom instructions'))
    async def test_review_preserves_constraints_and_unloads_last(self):
        r=await self.send(review=True,must_keep='Full body; right hand; exact text "Hello"',style='2D comic / cel shaded')
        self.assertEqual(r.status,200)
        self.assertEqual(len(self.calls),2)
        self.assertEqual(len(self.unloads),1)
        self.assertEqual(self.calls[0]['temperature'],.7)
        self.assertLessEqual(self.calls[1]['temperature'],.35)
        self.assertIn('Full body; right hand; exact text "Hello"',self.calls[1]['messages'][0]['content'])
        self.assertEqual(self.calls[1]['messages'][1]['content'],'A painted red boat.')
    async def test_creative_defaults_and_reference_limits(self):
        x=b.payload({'model':'gemma:test','brief':'A lonely robot at a bus stop'})
        self.assertIn('120–190 words',x['messages'][0]['content'])
        self.assertIn('ADD VISUAL VALUE',x['messages'][0]['content'])
        self.assertIn('active',x['messages'][0]['content'].lower())
        y=b.payload({'model':'gemma:test','brief':'Change the background only','mode':'Reference / edit'})
        self.assertIn('preserve the described source',y['messages'][0]['content'])
    async def test_review_does_not_flatten(self):
        r=await self.send(review=True); self.assertEqual(r.status,200)
        self.assertIn('Do NOT compress it into a paraphrase',self.calls[1]['messages'][-1]['content'])
        self.assertIn('preserve the imaginative supporting details',self.calls[1]['messages'][-1]['content'])
    async def test_invalid_controls(self):
        for extra in [{'style':'wrong'},{'length':'wrong'},{'mode':'wrong'},{'must_keep':3},{'review':'false'}]:
            r=await self.send(**extra); self.assertEqual(r.status,400)
        self.assertEqual(self.calls,[])
    async def test_context_guard(self):
        r=await self.send(brief='b'*24000,system='s'*24000,max_tokens=8192)
        self.assertEqual(r.status,400); self.assertEqual(self.calls,[])
    async def test_errors(self):
        for mode in ['missing','empty','length']:
            self.mode=mode; r=await self.send(); self.assertEqual(r.status,502)
            self.assertIn('error',await r.json())
    async def test_release_after_failed_review(self):
        self.mode='empty'; r=await self.send(review=True)
        self.assertEqual(r.status,502); self.assertEqual(self.unloads,[{'model':'custom/model:Q4'}])
    async def test_release_failure_preserves_finished_prompt(self):
        self.fail_unload=True; r=await self.send(); data=await r.json()
        self.assertEqual(r.status,200)
        self.assertEqual(data['prompt'],'A painted red boat on a quiet lake.')
        self.assertFalse(data['model_unloaded'])
        self.assertIn('could not unload',data['unload_warning'])
    async def test_invalid_input(self):
        for extra in [{'brief':''},{'max_tokens':1},{'temperature':9},{'action':'refine'},{'system':''}]:
            r=await self.send(**extra); self.assertEqual(r.status,400)
        self.assertEqual(self.calls,[])
    async def test_reference_enabled_sends_real_image_multimodal(self):
        # Minimal valid-looking JPEG signature for API validation (no pixel decoding on backend).
        sample = 'data:image/jpeg;base64,' + base64.b64encode(b'\xff\xd8\xff\xe0fakejpeg\xff\xd9').decode()
        r = await self.send(reference_enabled=True, reference_image=sample, review=True)
        self.assertEqual(r.status, 200, await r.text())
        self.assertEqual(len(self.calls), 2)
        first_user = self.calls[0]['messages'][1]['content']
        self.assertEqual(first_user[0], {'type':'text','text':'A painted red boat.'})
        self.assertEqual(first_user[1], {'type':'image_url','image_url':{'url':sample}})
        self.assertEqual(self.calls[1]['messages'][1]['content'], first_user)
        self.assertEqual(len(self.unloads), 1)
        self.assertIn('actual image', self.calls[0]['messages'][0]['content'])

    async def test_reference_off_does_not_send_image_even_if_provided(self):
        r = await self.send(reference_enabled=False, reference_image='invalid-image', review=False)
        self.assertEqual(r.status, 200)
        self.assertIsInstance(self.calls[0]['messages'][1]['content'], str)

    async def test_vision_rejection_on_text_only_model(self):
        sample = 'data:image/jpeg;base64,' + base64.b64encode(b'\xff\xd8\xffdata\xff\xd9').decode()
        r = await self.send(model='gemma:test', reference_enabled=True, reference_image=sample)
        self.assertEqual(r.status, 502)
        self.assertIn('no exact match was found', (await r.json())['error'])
        self.assertEqual(self.calls, [])
        self.assertEqual(self.unloads, [{'model':'gemma:test'}])

    async def test_enabled_reference_requires_valid_image(self):
        for image in [None, 'data:image/png;base64,abcd', 'data:image/jpeg;base64,!',
                      'data:image/jpeg;base64,' + base64.b64encode(b'bad').decode()]:
            r = await self.send(reference_enabled=True, reference_image=image)
            self.assertEqual(r.status, 400, await r.text())
        r = await self.send(reference_enabled='yes')
        self.assertEqual(r.status, 400)
        self.assertEqual(self.calls, [])

    async def test_preset_includes_matching_sibling_mmproj(self):
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            folder = Path(td)
            model = folder / 'gemma-4-12b-it-Q4_K_M.gguf'
            proj = folder / 'mmproj-F16.gguf'
            model.write_bytes(b'GGUF')
            proj.write_bytes(b'GGUF')
            # Explicit settings override from a temporary settings folder.
            old = b.settings_path
            b.settings_path = lambda: folder / 'settings.json'
            try:
                dest = b.write_model_preset(model)
                data = dest.read_text()
                self.assertIn(f'mmproj = {proj}', data)
                self.assertIn(f'model = {model}', data)
                proj.unlink()
                dest = b.write_model_preset(model)
                self.assertNotIn('mmproj =', dest.read_text())
            finally:
                b.settings_path = old

    async def test_cross_origin(self):
        r=await self.client.post('/krea2-writer/write',json={},headers={'Origin':'https://example.com'})
        self.assertEqual(r.status,403)
    async def test_busy(self):
        async with b.LOCK:
            r=await self.send(); self.assertEqual(r.status,409)
    async def test_offline(self):
        await self.llama.close()
        r=await self.client.get('/krea2-writer/models'); self.assertEqual(r.status,502)
        self.assertIn('Cannot find llama-server.exe',(await r.json())['error'])
    async def test_single_model_server_explained(self):
        self.no_router=True
        r=await self.client.get('/krea2-writer/models'); self.assertEqual(r.status,502)
        self.assertIn('single-model mode',(await r.json())['error'])
    async def test_single_model_server_cannot_generate(self):
        self.no_router=True
        r=await self.send(); self.assertEqual(r.status,502)
        self.assertIn('single-model mode', (await r.json())['error'])

if __name__ == '__main__': unittest.main(verbosity=2)

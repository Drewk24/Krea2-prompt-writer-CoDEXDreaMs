"""Browser smoke test; uses injected mocked ComfyUI hooks, never needs localhost network."""
import asyncio, tempfile
from pathlib import Path
from PIL import Image
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]
async def main():
    with tempfile.TemporaryDirectory() as td:
        path=Path(td)/'reference.png'
        Image.new('RGB',(1280,720),(42,120,160)).save(path)
        async with async_playwright() as p:
            browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
            page=await browser.new_page(viewport={'width':1280,'height':900}); page.set_default_timeout(4500)
            errors=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            await page.goto('about:blank')
            await page.add_style_tag(content=(ROOT/'web/writer.css').read_text())
            prefix='''
                window.__calls = [];
                const app={registerExtension(e){e.setup()}};
                const api={fetchApi:async(path,opts)=>{
                  let data={};
                  if(path.endsWith('/config')) data={system:'Test system instructions'};
                  if(path.endsWith('/models')) data={models:['gemma-4:Q4'], started:true};
                  if(path.endsWith('/write')) {
                      window.__calls.push(JSON.parse(opts.body));
                      data={prompt:'A moody noir scene using the actual reference image.',model_unloaded:true};
                  }
                  return {ok:true,json:async()=>data};
                }};
            '''
            writer=(ROOT/'web/writer.js').read_text().replace("import { app } from '../../scripts/app.js';",'').replace("import { api } from '../../scripts/api.js';",'').replace("new URL('./writer.css', import.meta.url).href", "'data:text/css,'")
            await page.add_script_tag(content=prefix+'\n'+writer)
            await page.locator('#krea2-writer-launcher').click()
            toggle=page.get_by_label('Enable Reference Image?')
            assert not await toggle.is_checked()
            assert not await page.get_by_label('Reference image selection').is_visible()
            await page.get_by_label('Describe your image').fill('Turn this into a noir scene')
            await toggle.check()
            assert await page.get_by_label('Reference image selection').is_visible()
            await page.get_by_label('Choose reference image file').set_input_files(str(path))
            await page.get_by_alt_text('Selected reference image preview').wait_for(state='visible')
            assert 'data:image/jpeg;base64,' in await page.get_by_alt_text('Selected reference image preview').get_attribute('src')
            await page.screenshot(path='/mnt/data/krea_reference_1280.png',full_page=True)
            await page.get_by_role('button',name='✦ Write prompt').click()
            assert 'noir scene' in await page.get_by_label('Your Krea prompt — editable').input_value()
            first=await page.evaluate('window.__calls')
            assert len(first)==1 and first[0]['reference_enabled'] is True and first[0]['reference_image'].startswith('data:image/jpeg;base64,')
            await toggle.uncheck()
            await page.get_by_role('button',name='✦ Write prompt').click()
            assert 'noir scene' in await page.get_by_label('Your Krea prompt — editable').input_value()
            calls=await page.evaluate('window.__calls')
            assert len(calls)==2 and calls[1]['reference_enabled'] is False and calls[1]['reference_image'] is None
            assert not await page.get_by_label('Reference image selection').is_visible()
            await toggle.check()
            await page.get_by_role('button',name='✕ Remove').click()
            await page.get_by_role('button',name='✦ Write prompt').click()
            await page.get_by_text('Choose a reference image, or switch it off.').wait_for()
            assert len(await page.evaluate('window.__calls'))==2
            assert not errors,errors
            await browser.close()
    print('PASS: opt-in, picker, preview, real image bytes, toggle off, removal error, zero JS errors')
asyncio.run(main())

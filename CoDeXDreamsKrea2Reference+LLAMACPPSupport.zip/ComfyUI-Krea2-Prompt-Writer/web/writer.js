import { app } from '../../scripts/app.js';
import { api } from '../../scripts/api.js';

const KEY = 'krea2-prompt-writer-v1'; // Retain drafts from Astra's original extension.
// Auto-migrate only the EXACT previous bundled preset, never customers' custom instructions.
function legacyPreset(text) {
    if (typeof text !== 'string' || text.length !== 3363) return false;
    let hash = 2166136261;
    for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619) >>> 0;
    return hash === 273751813;
}
let state = {};
try { state = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch {}
let official = '', dialog, status, model, brief, output, change, system, tokens, temperature;
let style, length, mode, mustKeep, review;
let referenceEnabled, referencePanel, referenceFile, referencePreview, referenceHint, referenceClear;
let referenceImage = null; // In-memory only; never stored in localStorage.
let busy = false;

function el(tag, props = {}, parent) {
    const element = document.createElement(tag);
    Object.assign(element, props);
    if (parent) parent.append(element);
    return element;
}
function field(label, tag, props = {}, parent, extraClass = '') {
    const wrap = el('label', { className: `kw-field ${extraClass}`.trim() }, parent);
    el('span', { textContent: label }, wrap);
    return el(tag, props, wrap);
}
function button(label, fn, parent, primary = false) {
    const b = el('button', { type: 'button', textContent: label, className: primary ? 'kw-primary' : '' }, parent);
    b.onclick = async () => {
        try { await fn(); }
        catch (error) { status.textContent = error.message || String(error); status.dataset.kind = 'error'; }
    };
    return b;
}
function save() {
    if (!model || !system) return;
    const draft = { model: model.value, brief: brief.value, output: output.value, change: change.value,
        version: 2, style: style.value, length: length.value, mode: mode.value, must_keep: mustKeep.value,
        review: review.checked, reference_enabled: referenceEnabled.checked,
        system: system.value, tokens: tokens.value, temperature: temperature.value };
    state = draft;
    try { localStorage.setItem(KEY, JSON.stringify(draft)); }
    catch { status.textContent = 'Browser storage unavailable. Copy your prompt before closing.'; }
}
async function request(path, body) {
    const response = await api.fetchApi('/krea2-writer/' + path, body === undefined ? {} : {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    let data;
    try { data = await response.json(); }
    catch { throw Error('Writer backend unavailable. Restart ComfyUI, then press Ctrl+F5.'); }
    if (!response.ok || data.error) throw Error(data.error || `Request failed (${response.status}).`);
    return data;
}
function populateModels(names, preferred, pickedAlias, pickedFilename) {
    model.replaceChildren();
    for (const name of names) {
        const title = name === pickedAlias && pickedFilename ? `📁 ${pickedFilename}` : name;
        el('option', { value: name, textContent: title }, model);
    }
    if (names.includes(preferred)) model.value = preferred;
}
async function browseModel() {
    if (busy) return;
    status.dataset.kind = '';
    status.textContent = 'Choose a GGUF file in the Windows file picker (not an upload)…';
    const data = await request('browse-model', {});
    if (data.cancelled) {
        status.textContent = 'Model selection cancelled. Nothing changed.';
        return;
    }
    populateModels(data.models, data.selected_model, data.selected_model, data.filename);
    status.dataset.kind = 'success';
    status.textContent = `Selected ${data.filename}. Saved for next time. Ready to write.`;
    save();
}
async function refresh() {
    status.dataset.kind = '';
    status.textContent = 'Connecting to llama.cpp (starting automatically if needed)…';
    const selected = model.value || state.model;
    const data = await request('models');
    populateModels(data.models, data.models.includes(selected) ? selected : data.selected_model, data.selected_model, data.selected_filename);
    status.textContent = data.models.length ? `${data.started ? 'llama.cpp started automatically · ' : ''}${data.models.length} models ready. Describe your image, then Write.` : 'No GGUF models detected. Click the folder icon beside the model selector to locate one already on your PC.';
    if (official) save();
}
async function write(action) {
    if (busy) return;
    if (!model.value) throw Error('Choose a llama.cpp GGUF model first.');
    if (!brief.value.trim()) throw Error('Describe the image first.');
    if (referenceEnabled.checked && !referenceImage) throw Error('Enable Reference Image is on. Choose a reference image, or switch it off.');
    if (!system.value.trim()) throw Error('System instructions are empty. Restore the defaults in Settings.');
    if (action === 'refine' && (!output.value.trim() || !change.value.trim())) throw Error('Add an existing prompt and describe what to change.');
    save();
    busy = true;
    dialog.querySelectorAll('[data-write]').forEach(b => b.disabled = true);
    status.dataset.kind = '';
    status.textContent = referenceEnabled.checked ? 'Preparing vision automatically, then writing locally… (first use can take longer)' : (review.checked ? 'Writing + reviewing locally…' : 'Writing locally…');
    try {
        const data = await request('write', { model: model.value, brief: brief.value, system: system.value,
            action, current: output.value, change: change.value, max_tokens: Number(tokens.value),
            style: style.value, length: length.value, mode: mode.value, must_keep: mustKeep.value,
            review: review.checked, temperature: Number(temperature.value),
            reference_enabled: referenceEnabled.checked,
            reference_image: referenceEnabled.checked ? referenceImage : null });
        output.value = data.prompt;
        status.dataset.kind = data.unload_warning ? 'warning' : 'success';
        status.textContent = data.unload_warning ? `Prompt ready. ${data.unload_warning}` :
            data.model_unloaded ? 'Prompt ready · llama.cpp model unloaded from RAM/VRAM.' :
                'Prompt ready · llama.cpp unload not confirmed.';
        save();
    } finally {
        busy = false;
        dialog.querySelectorAll('[data-write]').forEach(b => b.disabled = false);
    }
}
// Only compressed, local image bytes are sent to ComfyUI's local backend.
// No path/filename is sent to llama.cpp and the file is never uploaded to the internet.
function setReferenceVisibility() {
    referencePanel.hidden = !referenceEnabled.checked;
    referencePanel.setAttribute('aria-hidden', String(!referenceEnabled.checked));
    save();
}
function clearReference() {
    referenceImage = null;
    referenceFile.value = '';
    referencePreview.removeAttribute('src');
    referencePreview.hidden = true;
    referenceClear.hidden = true;
    referenceHint.textContent = 'Drop an image here or click Browse image.';
}
async function loadReferenceImage(file) {
    if (!file) return;
    if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type))
        throw Error('Reference image must be a PNG, JPEG or WebP file.');
    if (file.size > 20 * 1024 * 1024) throw Error('Reference image is too large (20 MB limit).');
    // createImageBitmap decodes locally before a capped canvas encode.
    const bitmap = await createImageBitmap(file);
    try {
        if (!bitmap.width || !bitmap.height || bitmap.width * bitmap.height > 120000000)
            throw Error('Invalid or oversized reference image.');
        const scale = Math.min(1, 1600 / Math.max(bitmap.width, bitmap.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(bitmap.width * scale));
        canvas.height = Math.max(1, Math.round(bitmap.height * scale));
        const context = canvas.getContext('2d', { alpha: false });
        if (!context) throw Error('Browser cannot prepare the reference image.');
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
        const encoded = canvas.toDataURL('image/jpeg', 0.88);
        if (!encoded.startsWith('data:image/jpeg;base64,') || encoded.length > 8 * 1024 * 1024)
            throw Error('Reference image could not be prepared. Try a smaller picture.');
        referenceImage = encoded;
        referencePreview.src = encoded;
        referencePreview.hidden = false;
        referenceClear.hidden = false;
        referenceHint.textContent = `${file.name} · ${canvas.width} × ${canvas.height} · ready`;
        status.dataset.kind = 'success';
        status.textContent = 'Reference image ready. Vision will be configured automatically when you write.';
    } finally { bitmap.close?.(); }
}
function build() {
    if (dialog) return;
    dialog = el('dialog', { id: 'krea2-writer-dialog', 'ariaLabel': 'Krea 2 Prompt Writer' }, document.body);
    const head = el('header', { className: 'kw-head' }, dialog);
    const heading = el('div', {}, head);
    el('h2', { textContent: 'Krea 2 · Prompt Writer' }, heading);
    el('p', { textContent: 'Local llama.cpp · independent ComfyUI utility' }, heading);
    const headRight = el('div', { className: 'kw-head-right' }, head);
    el('span', { className: 'kw-memory', textContent: 'Auto-unload after every prompt' }, headRight);
    button('✕  Close', () => { save(); dialog.close(); }, headRight);

    const main = el('main', { className: 'kw-main' }, dialog);
    const left = el('section', { className: 'kw-pane kw-left', 'ariaLabel': 'Prompt inputs' }, main);
    const modelRow = el('div', { className: 'kw-model-row' }, left);
    model = field('llama.cpp model', 'select', {}, modelRow);
    const browseButton = button('📁', browseModel, modelRow);
    browseButton.title = 'Browse your PC for an existing .gguf model (no upload or download)';
    browseButton.setAttribute('aria-label', 'Browse for GGUF model');
    browseButton.classList.add('kw-model-browse');
    button('↻ Refresh', refresh, modelRow);
    brief = field('Describe your image', 'textarea', { value: state.brief || '', rows: 6,
        placeholder: 'Describe a simple idea—I will develop it into a complete scene. Include anything that must stay exact…' }, left, 'kw-brief');

    // Independent opt-in control, OFF by default unless the customer previously enabled it.
    const reference = el('section', { className: 'kw-reference' }, left);
    const referenceSwitch = el('label', { className: 'kw-reference-switch' }, reference);
    referenceEnabled = el('input', { type: 'checkbox', checked: state.reference_enabled === true }, referenceSwitch);
    el('span', { textContent: 'Enable Reference Image?' }, referenceSwitch);
    referencePanel = el('div', { className: 'kw-reference-panel' }, reference);
    const dropzone = el('div', { className: 'kw-reference-dropzone', tabIndex: 0,
        role: 'group', 'ariaLabel': 'Reference image selection' }, referencePanel);
    referencePreview = el('img', { className: 'kw-reference-preview', alt: 'Selected reference image preview', hidden: true }, dropzone);
    const dropInfo = el('div', { className: 'kw-reference-info' }, dropzone);
    el('strong', { textContent: 'Reference image' }, dropInfo);
    referenceHint = el('span', { textContent: 'Drop an image here or click Browse image.' }, dropInfo);
    const refActions = el('div', { className: 'kw-reference-buttons' }, dropInfo);
    referenceFile = el('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', className: 'kw-image-file',
        'ariaLabel': 'Choose reference image file' }, refActions);
    button('📁 Browse image', () => referenceFile.click(), refActions);
    referenceClear = button('✕ Remove', () => { clearReference(); save(); }, refActions);
    referenceClear.hidden = true;
    el('p', { className: 'kw-help', textContent: 'Reference images stay local. With this option on, the Writer automatically configures vision; supported models may download a matching vision component once. No image is sent when off.' }, referencePanel);
    referenceFile.addEventListener('change', async () => {
        try { await loadReferenceImage(referenceFile.files?.[0]); }
        catch (error) { status.dataset.kind = 'error'; status.textContent = error.message || String(error); }
    });
    dropzone.addEventListener('dragover', ev => {
        if (!referenceEnabled.checked) return;
        ev.preventDefault(); dropzone.classList.add('kw-dragover');
    });
    dropzone.addEventListener('dragleave', () => dropzone.classList.remove('kw-dragover'));
    dropzone.addEventListener('drop', async ev => {
        if (!referenceEnabled.checked) return;
        ev.preventDefault(); dropzone.classList.remove('kw-dragover');
        try { await loadReferenceImage(ev.dataTransfer?.files?.[0]); }
        catch (error) { status.dataset.kind = 'error'; status.textContent = error.message || String(error); }
    });
    referenceEnabled.addEventListener('change', setReferenceVisibility);
    setReferenceVisibility();
    const picks = el('div', { className: 'kw-picks' }, left);
    function select(label, values, saved) {
        const control = field(label, 'select', {}, picks);
        for (const v of values) el('option', { value: v, textContent: v }, control);
        if (values.includes(saved)) control.value = saved;
        return control;
    }
    mode = select('Task', ['New image', 'Reference / edit'], state.mode);
    style = select('Style', ['Follow my brief', '2D comic / cel shaded', 'Anime / hand drawn', 'Photograph', '3D render'], state.style);
    length = select('Detail', ['Short', 'Balanced', 'Detailed'], state.length || 'Balanced');
    mustKeep = field('Must keep · optional', 'textarea', { value: state.must_keep || '', rows: 2,
        placeholder: 'Exact traits, outfit, proportions, framing, text, trigger words…' }, left, 'kw-keep');
    const flags = el('div', { className: 'kw-flags' }, left);
    const reviewLabel = el('label', { className: 'kw-check' }, flags);
    review = el('input', { type: 'checkbox', checked: state.review !== false }, reviewLabel);
    el('span', { textContent: 'Quality review (2 passes)' }, reviewLabel);
    el('span', { className: 'kw-help', textContent: 'New images get creative scene details. Reference/edit stays faithful to your description.' }, flags);
    const leftActions = el('div', { className: 'kw-actions' }, left);
    button('✦ Write prompt', () => write('write'), leftActions, true).dataset.write = '1';

    const right = el('section', { className: 'kw-pane kw-right', 'ariaLabel': 'Written prompt and refinement' }, main);
    const outputHead = el('div', { className: 'kw-output-head' }, right);
    el('strong', { textContent: 'Your prompt · editable' }, outputHead);
    button('Copy prompt', async () => {
        if (!output.value.trim()) throw Error('Write a prompt first.');
        try { await navigator.clipboard.writeText(output.value); }
        catch {
            output.focus(); output.select();
            if (!document.execCommand('copy')) throw Error('Prompt selected. Press Ctrl+C to copy.');
        }
        status.dataset.kind = 'success';
        status.textContent = 'Copied. Paste it into your Krea workflow.';
    }, outputHead);
    output = field('Your Krea prompt — editable', 'textarea', { value: state.output || '', rows: 10,
        placeholder: 'Your generated prompt will appear here. You can also edit it directly.' }, right, 'kw-output');
    change = field('Refine · what should change?', 'textarea', { value: state.change || '', rows: 2,
        placeholder: 'Keep everything else; change the lighting to sunset…' }, right, 'kw-change');
    const rightActions = el('div', { className: 'kw-actions' }, right);
    button('↻ Refine prompt', () => write('refine'), rightActions).dataset.write = '1';
    status = el('p', { className: 'kw-status', textContent: 'Loading…' }, right);
    status.setAttribute('role', 'status');

    const advanced = el('details', { className: 'kw-advanced' }, dialog);
    el('summary', { textContent: '⚙ Settings & writer instructions' }, advanced);
    const advancedBody = el('div', { className: 'kw-advanced-body' }, advanced);
    const opts = el('div', { className: 'kw-picks kw-options' }, advancedBody);
    tokens = field('Max output tokens', 'input', { type: 'number', min: 256, max: 8192, step: 256, value: state.tokens || 1536 }, opts);
    temperature = field('Temperature', 'input', { type: 'number', min: 0, max: 2, step: 0.1, value: state.temperature ?? 0.7 }, opts);
    el('p', { className: 'kw-help', textContent: 'Model release is always on: unloads the llama.cpp router model after each run, even when generation fails. It does not unload Krea or other ComfyUI models.' }, advancedBody);
    system = field('System instructions', 'textarea', { value: state.system ?? '', rows: 7 }, advancedBody);
    button('Restore upgraded instructions', () => {
        system.value = official; save(); status.dataset.kind = '';
        status.textContent = 'Default instructions restored.';
    }, advancedBody);

    for (const control of [brief, output, change, tokens, temperature, system, model, style, length, mode, mustKeep, review]) {
        control.addEventListener('change', save);
    }
    for (const control of [brief, output, change, system, mustKeep]) control.addEventListener('input', save);
    dialog.addEventListener('cancel', save);
}
async function open() {
    build();
    if (!dialog.open) dialog.showModal();
    try {
        if (!official) {
            const data = await request('config'); official = data.system;
            if (state.version !== 2 || state.system == null || legacyPreset(state.system)) {
                system.value = official;
            }
        }
        if (!model.options.length) await refresh();
    } catch (error) { status.dataset.kind = 'error'; status.textContent = error.message; }
}
// The ComfyUI Desktop graph, overlays, and side panels can sit above a button
// styled with a low CSS z-index. Keep the launcher visible even when an
// extension stylesheet is delayed, blocked, or overridden by the host UI.
let launcherDomReadyScheduled = false;
function ensureLauncher() {
    if (!document.body) {
        if (!launcherDomReadyScheduled) {
            launcherDomReadyScheduled = true;
            document.addEventListener('DOMContentLoaded', () => {
                launcherDomReadyScheduled = false;
                ensureLauncher();
            }, { once: true });
        }
        return;
    }
    let launcher = document.getElementById('krea2-writer-launcher');
    if (!launcher) {
        launcher = el('button', { id: 'krea2-writer-launcher', type: 'button' }, document.body);
    } else if (launcher.parentElement !== document.body) {
        document.body.append(launcher);
    }
    launcher.textContent = 'Krea 2 Writer';
    launcher.title = 'Open Prompt Writer for Krea 2';
    launcher.onclick = open;
    launcher.setAttribute('aria-label', 'Open Krea 2 Prompt Writer');
    // Inline !important deliberately wins against existing ComfyUI theme CSS.
    const critical = {
        'position': 'fixed', 'right': '24px', 'bottom': '142px',
        'z-index': '2147483647', 'display': 'inline-flex',
        'visibility': 'visible', 'opacity': '1', 'pointer-events': 'auto',
        'align-items': 'center', 'justify-content': 'center',
        'background': '#88dbb7', 'color': '#12231c',
        'border': '1px solid #b3f4d8', 'border-radius': '24px',
        'padding': '11px 18px', 'font': '600 14px system-ui',
        'box-shadow': '0 4px 18px #0009', 'cursor': 'pointer',
        'min-height': '38px', 'white-space': 'nowrap'
    };
    for (const [name, value] of Object.entries(critical)) {
        launcher.style.setProperty(name, value, 'important');
    }
}
function ensureLauncherStyles() {
    if (!document.querySelector('link[data-krea-writer="1"]')) {
        const css = el('link', { rel: 'stylesheet', href: new URL('./writer.css', import.meta.url).href }, document.head);
        css.dataset.kreaWriter = '1';
    }
}
function mountLauncher() {
    ensureLauncherStyles();
    ensureLauncher();
}
app.registerExtension({
    name: 'Krea2.PromptWriter',
    async init() { mountLauncher(); },
    async setup() { mountLauncher(); }
});

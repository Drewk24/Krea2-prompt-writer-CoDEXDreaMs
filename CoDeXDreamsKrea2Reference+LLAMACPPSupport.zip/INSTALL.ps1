# Customer installer for the independent Krea 2 Prompt Writer extension.
# The installer NEVER assumes any developer's PC location.
# Put this script beside the ComfyUI-Krea2-Prompt-Writer folder.
param([string]$ComfyRoot = '')
$ErrorActionPreference = 'Stop'

function Get-FullPath([string]$value) {
    if ([string]::IsNullOrWhiteSpace($value)) { return '' }
    try { return [IO.Path]::GetFullPath($value.Trim().Trim('"')) }
    catch { return '' }
}

function Test-ComfyRoot([string]$value) {
    $p = Get-FullPath $value
    if (-not $p) { return $false }
    return ((Test-Path -LiteralPath (Join-Path $p 'main.py') -PathType Leaf) -and
            (Test-Path -LiteralPath (Join-Path $p 'custom_nodes') -PathType Container))
}

try {
    $packageDir = Get-FullPath $PSScriptRoot
    $sourceDir = Join-Path $packageDir 'ComfyUI-Krea2-Prompt-Writer'
    $required = @('__init__.py', 'backend.py', 'web\writer.js',
                  'web\writer.css', 'prompts\writer_v2.txt')
    foreach ($name in $required) {
        if (-not (Test-Path -LiteralPath (Join-Path $sourceDir $name) -PathType Leaf)) {
            throw "Missing required package file: $name. Extract the WHOLE ZIP, keeping the folder structure."
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($ComfyRoot)) {
        if (-not (Test-ComfyRoot $ComfyRoot)) {
            throw "Provided ComfyUI location is invalid: $ComfyRoot (requires main.py and custom_nodes)."
        }
    } elseif (Test-ComfyRoot $packageDir) {
        # The customer placed the installer directly into their ComfyUI directory.
        $ComfyRoot = $packageDir
    } else {
        Write-Host ''
        Write-Host 'Krea 2 Prompt Writer - CUSTOMER INSTALLER' -ForegroundColor Cyan
        Write-Host 'No preset install path is used.'
        Write-Host 'Paste YOUR ComfyUI folder containing main.py and custom_nodes.'
        Write-Host '(ComfyUI Desktop and portable installs are both supported if the path is correct.)'
        $ComfyRoot = Read-Host 'ComfyUI folder'
        if (-not (Test-ComfyRoot $ComfyRoot)) {
            throw 'Invalid ComfyUI directory. No files have been changed.'
        }
    }

    $ComfyRoot = Get-FullPath $ComfyRoot
    $customNodes = Join-Path $ComfyRoot 'custom_nodes'
    $targetDir = Join-Path $customNodes 'ComfyUI-Krea2-Prompt-Writer'
    $stageDir = Join-Path $customNodes ('.krea-writer-install-' + [guid]::NewGuid().ToString('N'))
    $backupDir = ''
    $oldMoved = $false

    Write-Host ''
    Write-Host "Installing into: $targetDir" -ForegroundColor Cyan

    # Stage all files before touching the user's existing installation.
    try {
        Copy-Item -LiteralPath $sourceDir -Destination $stageDir -Recurse -Force
        foreach ($name in $required) {
            if (-not (Test-Path -LiteralPath (Join-Path $stageDir $name) -PathType Leaf)) {
                throw "Staged extension failed validation: $name"
            }
        }

        if (Test-Path -LiteralPath $targetDir) {
            $backupRoot = Join-Path $ComfyRoot 'krea-writer-backups'
            New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
            $backupDir = Join-Path $backupRoot ('ComfyUI-Krea2-Prompt-Writer-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N'))
            Move-Item -LiteralPath $targetDir -Destination $backupDir
            $oldMoved = $true
            Write-Host "Existing version backed up to: $backupDir"
        }
        Move-Item -LiteralPath $stageDir -Destination $targetDir
    } catch {
        # Restore old extension if activation fails after backing it up.
        if ($oldMoved -and (Test-Path -LiteralPath $backupDir) -and -not (Test-Path -LiteralPath $targetDir)) {
            try {
                Move-Item -LiteralPath $backupDir -Destination $targetDir
                Write-Host 'Previous installation restored.' -ForegroundColor Yellow
            } catch {
                Write-Warning "Automatic rollback failed. Your original extension is stored in $backupDir"
            }
        }
        throw
    } finally {
        if (Test-Path -LiteralPath $stageDir) {
            Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    Write-Host ''
    Write-Host 'SUCCESS - Prompt Writer installed.' -ForegroundColor Green
    Write-Host "ComfyUI root: $ComfyRoot"
    Write-Host 'Restart ComfyUI, then press Ctrl+F5 in the browser to refresh the UI.'
    Write-Host 'llama.cpp launches automatically when you open the Writer. You install your own GGUF model.'
    exit 0
} catch {
    Write-Host ''
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}

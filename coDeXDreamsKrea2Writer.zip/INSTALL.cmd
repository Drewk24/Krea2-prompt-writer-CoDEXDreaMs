@echo off
setlocal
set "SCRIPT_DIR=%~dp0"
if not exist "%SCRIPT_DIR%INSTALL.ps1" (
    echo ERROR: INSTALL.ps1 is missing. Extract the ENTIRE ZIP first.
    pause
    exit /b 1
)
if not exist "%SCRIPT_DIR%ComfyUI-Krea2-Prompt-Writer\__init__.py" (
    echo ERROR: Extension files are missing. Extract the ENTIRE ZIP first.
    pause
    exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%INSTALL.ps1"
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo INSTALLATION FAILED. Nothing from this package was intentionally removed.
if "%RESULT%"=="0" echo You can close this window and restart ComfyUI.
pause
exit /b %RESULT%

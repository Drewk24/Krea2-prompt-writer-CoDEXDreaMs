import importlib.util
import sys
import types
import unittest
from pathlib import Path
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

ROOT = Path(__file__).resolve().parents[1]
routes = web.RouteTableDef()
sys.modules['server'] = types.SimpleNamespace(PromptServer=types.SimpleNamespace(instance=types.SimpleNamespace(routes=routes)))
spec = importlib.util.spec_from_file_location('writer_backend', ROOT / 'backend.py')
b = importlib.util.module_from_spec(spec)
spec.loader.exec_module(b)

class BackendTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.calls = []
        self.unloads = []
        self.fail_unload = False
        self.mode = 'ok'
        async def chat(request):
            data = await request.json(); self.calls.append(data)
            if self.mode == 'unsupported' and 'think' in data:
                return web.json_response({'error': 'model does not support thinking'}, status=400)
            if self.mode == 'missing':
                return web.json_response({'error': 'model not found'}, status=404)
            if self.mode == 'empty':
                return web.json_response({'message': {'content': ''}})
            if self.mode == 'length':
                return web.json_response({'message': {'content': 'partial'}, 'done_reason': 'length'})
            return web.json_response({'message': {'content': '<think>hidden</think>A painted red boat on a quiet lake.'}, 'done_reason': 'stop'})
        async def unload(request):
            data = await request.json()
            self.unloads.append(data)
            if self.fail_unload:
                return web.json_response({'error': 'could not unload'}, status=503)
            return web.json_response({'done': True, 'done_reason': 'unload'})
        async def tags(request):
            return web.json_response({'models': [{'name': 'custom/model:Q4'}, {'name': 'gemma:test'}]})
        mock = web.Application(); mock.router.add_post('/api/chat', chat); mock.router.add_post('/api/generate', unload); mock.router.add_get('/api/tags', tags)
        self.ollama = TestServer(mock); await self.ollama.start_server()
        b.OLLAMA_URL = str(self.ollama.make_url('')).rstrip('/')
        b.LOCK = __import__('asyncio').Lock()
        app = web.Application(); app.add_routes(routes)
        self.client = TestClient(TestServer(app)); await self.client.start_server()
    async def asyncTearDown(self):
        await self.client.close(); await self.ollama.close()
    async def send(self, **extra):
        return await self.client.post('/krea2-writer/write', json={'model': 'custom/model:Q4', 'brief': 'A painted red boat.', 'review': False, **extra})
    async def test_config_and_models(self):
        r = await self.client.get('/krea2-writer/config'); self.assertEqual((await r.json())['system'], b.DEFAULT)
        r = await self.client.get('/krea2-writer/models'); self.assertIn('custom/model:Q4', (await r.json())['models'])
    async def test_write_and_unload(self):
        r = await self.send(); self.assertEqual(r.status, 200)
        self.assertEqual((await r.json())['prompt'], 'A painted red boat on a quiet lake.')
        self.assertTrue(self.calls[0]['messages'][0]['content'].startswith(b.DEFAULT))
        self.assertEqual(self.calls[0]['keep_alive'], 0)
        self.assertFalse(self.calls[0]['stream'])
        self.assertEqual(self.unloads, [{'model': 'custom/model:Q4', 'keep_alive': 0, 'stream': False}])
        self.assertTrue((await r.json())['model_unloaded'])
    async def test_refine_and_custom_system(self):
        r = await self.send(action='refine', current='A red boat.', change='Make it blue.', system='Custom instructions', unload=False)
        self.assertEqual(r.status, 200)
        self.assertEqual([m['role'] for m in self.calls[0]['messages']], ['system','user','assistant','user'])
        self.assertEqual(self.calls[0]['keep_alive'], 0)
        self.assertEqual(len(self.unloads), 1)  # Legacy unload=False cannot disable cleanup.
        self.assertTrue(self.calls[0]['messages'][0]['content'].startswith('Custom instructions'))
    async def test_review_preserves_constraints_and_unloads_last(self):
        r = await self.send(review=True, must_keep='Full body; right hand; exact text "Hello"', style='2D comic / cel shaded')
        self.assertEqual(r.status, 200)
        self.assertEqual(len(self.calls), 2)
        self.assertEqual(len(self.unloads), 1)
        self.assertEqual(self.calls[0]['keep_alive'], '5m')
        self.assertEqual(self.calls[1]['keep_alive'], 0)
        self.assertIn('Full body; right hand; exact text "Hello"', self.calls[1]['messages'][0]['content'])
        self.assertEqual(self.calls[1]['messages'][1]['content'], 'A painted red boat.')
        self.assertLessEqual(self.calls[1]['options']['temperature'], .35)
    async def test_creative_defaults_and_reference_limits(self):
        request = b.payload({'model':'gemma:test', 'brief':'A lonely robot at a bus stop'})
        sys_prompt = request['messages'][0]['content']
        self.assertEqual(request['options']['temperature'], 0.7)
        self.assertIn('120–190 words', sys_prompt)
        self.assertIn('ADD VISUAL VALUE', sys_prompt)
        self.assertIn('active', sys_prompt.lower())
        r = b.payload({'model':'gemma:test','brief':'Change the background only', 'mode':'Reference / edit'})
        self.assertIn('preserve the described source',r['messages'][0]['content'])

    async def test_review_does_not_flatten_image_detail(self):
        r=await self.send(review=True)
        self.assertEqual(r.status,200)
        self.assertIn('Do NOT compress it into a paraphrase', self.calls[1]['messages'][-1]['content'])
        self.assertIn('preserve the imaginative supporting details', self.calls[1]['messages'][-1]['content'])

    async def test_invalid_controls(self):
        for extra in [{'style': 'wrong'}, {'length': 'wrong'}, {'mode': 'wrong'}, {'must_keep': 3}, {'review': 'false'}]:
            r = await self.send(**extra)
            self.assertEqual(r.status, 400)
        self.assertEqual(self.calls, [])
    async def test_context_guard(self):
        r = await self.send(brief='b'*24000, system='s'*24000, max_tokens=8192)
        self.assertEqual(r.status, 400)
        self.assertEqual(self.calls, [])
    async def test_thinking_fallback(self):
        self.mode='unsupported'; r=await self.send(); self.assertEqual(r.status,200); self.assertEqual(len(self.calls),2); self.assertNotIn('think',self.calls[1])
    async def test_errors(self):
        for mode in ['missing','empty','length']:
            self.mode=mode; r=await self.send(); self.assertEqual(r.status,502); self.assertIn('error',await r.json())
    async def test_release_after_failed_review(self):
        self.mode = 'empty'
        r = await self.send(review=True)
        self.assertEqual(r.status, 502)
        self.assertEqual(len(self.unloads), 1)
    async def test_release_failure_preserves_finished_prompt(self):
        self.fail_unload = True
        r = await self.send()
        result = await r.json()
        self.assertEqual(r.status, 200)
        self.assertEqual(result['prompt'], 'A painted red boat on a quiet lake.')
        self.assertFalse(result['model_unloaded'])
        self.assertIn('could not unload', result['unload_warning'])
    async def test_invalid_input(self):
        for extra in [{'brief':''},{'max_tokens':1},{'temperature':9},{'action':'refine'},{'system':''}]:
            r=await self.send(**extra); self.assertEqual(r.status,400)
        self.assertEqual(self.calls,[])
    async def test_cross_origin(self):
        r=await self.client.post('/krea2-writer/write',json={},headers={'Origin':'https://example.com'})
        self.assertEqual(r.status,403)
    async def test_busy(self):
        async with b.LOCK:
            r=await self.send(); self.assertEqual(r.status,409)
    async def test_offline(self):
        await self.ollama.close()
        r=await self.client.get('/krea2-writer/models'); self.assertEqual(r.status,502)
        self.assertIn('Cannot reach Ollama',(await r.json())['error'])

if __name__ == '__main__': unittest.main()

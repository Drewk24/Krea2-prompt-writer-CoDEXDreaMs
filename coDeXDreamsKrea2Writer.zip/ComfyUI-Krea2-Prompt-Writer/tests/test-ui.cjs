const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), assert = require('assert');
const root = require('path').resolve(__dirname, '..');
let calls=[], fail=false;
const server=http.createServer((req,res)=>{
 const u=req.url;
 if(u==='/'){res.setHeader('Content-Type','text/html');return res.end('<html><head></head><body><script type="module" src="/extensions/krea/writer.js"></script></body></html>');}
 if(u==='/scripts/app.js'){res.setHeader('Content-Type','text/javascript');return res.end('export const app={registerExtension(e){e.setup()}};');}
 if(u==='/scripts/api.js'){res.setHeader('Content-Type','text/javascript');return res.end('export const api={fetchApi:(path,opts)=>fetch(path,opts)};');}
 if(u==='/extensions/krea/writer.js'||u==='/extensions/krea/writer.css'){
  res.setHeader('Content-Type',u.endsWith('.js')?'text/javascript':'text/css');return res.end(fs.readFileSync(root+'/web/'+u.split('/').pop()));
 }
 res.setHeader('Content-Type','application/json');
 if(u==='/krea2-writer/config')return res.end(JSON.stringify({system:fs.readFileSync(root+'/prompts/writer_v2.txt','utf8')}));
 if(u==='/krea2-writer/models')return res.end(JSON.stringify({models:['custom/gemma:Q4','other:model']}));
 if(u==='/krea2-writer/write'){
  let body='';req.on('data',d=>body+=d);return req.on('end',()=>{calls.push(JSON.parse(body));if(fail){res.statusCode=502;res.end(JSON.stringify({error:'Ollama test error'}));}else res.end(JSON.stringify({prompt:calls.at(-1).action==='refine'?'A blue painted boat.':'A red painted boat.',model_unloaded:true,unload_warning:null}));});
 }
 res.statusCode=404;res.end('{}');
});
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 try{
 const page=await browser.newPage({viewport:{width:1200,height:1000}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:'+server.address().port);
 await page.getByRole('button',{name:'Krea 2 Writer',exact:true}).click();
 await page.getByText('2 models ready.',{exact:false}).waitFor();
 await page.getByLabel('Describe your image').fill('A red painted boat.');
 await page.getByLabel('Style',{exact:true}).selectOption('2D comic / cel shaded');
 await page.getByLabel('Must keep · optional').fill('Right hand, full body');
 await page.getByRole('button',{name:'✦ Write prompt',exact:true}).click();
 await page.waitForFunction(()=>[...document.querySelectorAll('textarea')].find(x=>x.closest('label').textContent.includes('Your Krea prompt')).value==='A red painted boat.');
 await page.getByLabel('Refine · what should change?').fill('Make it blue.');
 await page.getByRole('button',{name:'↻ Refine prompt',exact:true}).click();
 await page.waitForFunction(()=>[...document.querySelectorAll('textarea')].find(x=>x.closest('label').textContent.includes('Your Krea prompt')).value==='A blue painted boat.');
 assert.equal(calls[1].current,'A red painted boat.');assert.equal(calls[1].unload,undefined);assert.equal(calls[0].review,true);assert.equal(calls[0].style,'2D comic / cel shaded');assert.equal(calls[0].must_keep,'Right hand, full body');
 await page.getByRole('button',{name:'Copy prompt',exact:true}).click();
 await page.getByText('Copied. Paste it into your Krea workflow.').waitFor();
 fail=true;
 await page.getByRole('button',{name:'✦ Write prompt',exact:true}).click();
 await page.getByText('Ollama test error').waitFor();
 assert.equal(await page.getByLabel('Your Krea prompt — editable').inputValue(),'A blue painted boat.');
 await page.getByRole('button',{name:'✕  Close',exact:true}).click();await page.reload();
 await page.getByRole('button',{name:'Krea 2 Writer',exact:true}).click();
 await page.getByText('2 models ready.',{exact:false}).waitFor();
 assert.equal(await page.getByLabel('Your Krea prompt — editable').inputValue(),'A blue painted boat.');
 await page.getByText('⚙ Settings & writer instructions',{exact:true}).click();
 assert.equal(await page.getByLabel('System instructions',{exact:true}).inputValue(),fs.readFileSync(root+'/prompts/writer_v2.txt','utf8'));
 await page.getByLabel('System instructions',{exact:true}).fill('Custom');
 await page.getByRole('button',{name:'Restore upgraded instructions'}).click();
 assert.equal(await page.getByLabel('System instructions',{exact:true}).inputValue(),fs.readFileSync(root+'/prompts/writer_v2.txt','utf8'));
 await page.getByText('⚙ Settings & writer instructions',{exact:true}).click();
 
 assert.deepEqual(errors,[]);
 console.log('PASS: launcher, model dropdown, write, refine, copy, error preservation, draft persistence, official instructions restore; no browser errors.');
 }finally{await browser.close();server.close();}
})().catch(e=>{console.error(e);server.close();process.exitCode=1;});

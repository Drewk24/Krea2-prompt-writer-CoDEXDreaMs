import { app } from '../../scripts/app.js';
import { api } from '../../scripts/api.js';

const KEY = 'krea2-prompt-writer-v1'; // Retain drafts from Astra's original extension.
// Auto-migrate only the EXACT previous bundled preset, never customers' custom instructions.
function legacyPreset(text) {
    if (typeof text !== 'string' || text.length !== 3363) return false;
    let hash = 2166136261;
    for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619) >>> 0;
    return hash === 273751813;
}
let state = {};
try { state = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch {}
let official = '', dialog, status, model, brief, output, change, system, tokens, temperature;
let style, length, mode, mustKeep, review;
let busy = false;

function el(tag, props = {}, parent) {
    const element = document.createElement(tag);
    Object.assign(element, props);
    if (parent) parent.append(element);
    return element;
}
function field(label, tag, props = {}, parent, extraClass = '') {
    const wrap = el('label', { className: `kw-field ${extraClass}`.trim() }, parent);
    el('span', { textContent: label }, wrap);
    return el(tag, props, wrap);
}
function button(label, fn, parent, primary = false) {
    const b = el('button', { type: 'button', textContent: label, className: primary ? 'kw-primary' : '' }, parent);
    b.onclick = async () => {
        try { await fn(); }
        catch (error) { status.textContent = error.message || String(error); status.dataset.kind = 'error'; }
    };
    return b;
}
function save() {
    if (!model || !system) return;
    const draft = { model: model.value, brief: brief.value, output: output.value, change: change.value,
        version: 2, style: style.value, length: length.value, mode: mode.value, must_keep: mustKeep.value,
        review: review.checked, system: system.value, tokens: tokens.value, temperature: temperature.value };
    state = draft;
    try { localStorage.setItem(KEY, JSON.stringify(draft)); }
    catch { status.textContent = 'Browser storage unavailable. Copy your prompt before closing.'; }
}
async function request(path, body) {
    const response = await api.fetchApi('/krea2-writer/' + path, body === undefined ? {} : {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    });
    let data;
    try { data = await response.json(); }
    catch { throw Error('Writer backend unavailable. Restart ComfyUI, then press Ctrl+F5.'); }
    if (!response.ok || data.error) throw Error(data.error || `Request failed (${response.status}).`);
    return data;
}
async function refresh() {
    status.dataset.kind = '';
    status.textContent = 'Checking installed Ollama models…';
    const selected = model.value || state.model;
    const data = await request('models');
    model.replaceChildren();
    for (const name of data.models) el('option', { value: name, textContent: name }, model);
    if (data.models.includes(selected)) model.value = selected;
    status.textContent = data.models.length ? `${data.models.length} models ready. Describe your image, then Write.` : 'No Ollama models found. Install a model in Ollama, then refresh.';
    if (official) save();
}
async function write(action) {
    if (busy) return;
    if (!model.value) throw Error('Choose an Ollama model first.');
    if (!brief.value.trim()) throw Error('Describe the image first.');
    if (!system.value.trim()) throw Error('System instructions are empty. Restore the defaults in Settings.');
    if (action === 'refine' && (!output.value.trim() || !change.value.trim())) throw Error('Add an existing prompt and describe what to change.');
    save();
    busy = true;
    dialog.querySelectorAll('[data-write]').forEach(b => b.disabled = true);
    status.dataset.kind = '';
    status.textContent = review.checked ? 'Writing + reviewing locally…' : 'Writing locally…';
    try {
        const data = await request('write', { model: model.value, brief: brief.value, system: system.value,
            action, current: output.value, change: change.value, max_tokens: Number(tokens.value),
            style: style.value, length: length.value, mode: mode.value, must_keep: mustKeep.value,
            review: review.checked, temperature: Number(temperature.value) });
        output.value = data.prompt;
        status.dataset.kind = data.unload_warning ? 'warning' : 'success';
        status.textContent = data.unload_warning ? `Prompt ready. ${data.unload_warning}` :
            data.model_unloaded ? 'Prompt ready · Ollama model released from memory.' :
                'Prompt ready · Ollama release requested.';
        save();
    } finally {
        busy = false;
        dialog.querySelectorAll('[data-write]').forEach(b => b.disabled = false);
    }
}
function build() {
    if (dialog) return;
    dialog = el('dialog', { id: 'krea2-writer-dialog', 'ariaLabel': 'Krea 2 Prompt Writer' }, document.body);
    const head = el('header', { className: 'kw-head' }, dialog);
    const heading = el('div', {}, head);
    el('h2', { textContent: 'Krea 2 · Prompt Writer' }, heading);
    el('p', { textContent: 'Local Ollama · independent ComfyUI utility' }, heading);
    const headRight = el('div', { className: 'kw-head-right' }, head);
    el('span', { className: 'kw-memory', textContent: 'Auto-unload after every prompt' }, headRight);
    button('✕  Close', () => { save(); dialog.close(); }, headRight);

    const main = el('main', { className: 'kw-main' }, dialog);
    const left = el('section', { className: 'kw-pane kw-left', 'ariaLabel': 'Prompt inputs' }, main);
    const modelRow = el('div', { className: 'kw-model-row' }, left);
    model = field('Ollama model', 'select', {}, modelRow);
    button('↻ Refresh', refresh, modelRow);
    brief = field('Describe your image', 'textarea', { value: state.brief || '', rows: 6,
        placeholder: 'Describe a simple idea—I will develop it into a complete scene. Include anything that must stay exact…' }, left, 'kw-brief');

    const picks = el('div', { className: 'kw-picks' }, left);
    function select(label, values, saved) {
        const control = field(label, 'select', {}, picks);
        for (const v of values) el('option', { value: v, textContent: v }, control);
        if (values.includes(saved)) control.value = saved;
        return control;
    }
    mode = select('Task', ['New image', 'Reference / edit'], state.mode);
    style = select('Style', ['Follow my brief', '2D comic / cel shaded', 'Anime / hand drawn', 'Photograph', '3D render'], state.style);
    length = select('Detail', ['Short', 'Balanced', 'Detailed'], state.length || 'Balanced');
    mustKeep = field('Must keep · optional', 'textarea', { value: state.must_keep || '', rows: 2,
        placeholder: 'Exact traits, outfit, proportions, framing, text, trigger words…' }, left, 'kw-keep');
    const flags = el('div', { className: 'kw-flags' }, left);
    const reviewLabel = el('label', { className: 'kw-check' }, flags);
    review = el('input', { type: 'checkbox', checked: state.review !== false }, reviewLabel);
    el('span', { textContent: 'Quality review (2 passes)' }, reviewLabel);
    el('span', { className: 'kw-help', textContent: 'New images get creative scene details. Reference/edit stays faithful to your description.' }, flags);
    const leftActions = el('div', { className: 'kw-actions' }, left);
    button('✦ Write prompt', () => write('write'), leftActions, true).dataset.write = '1';

    const right = el('section', { className: 'kw-pane kw-right', 'ariaLabel': 'Written prompt and refinement' }, main);
    const outputHead = el('div', { className: 'kw-output-head' }, right);
    el('strong', { textContent: 'Your prompt · editable' }, outputHead);
    button('Copy prompt', async () => {
        if (!output.value.trim()) throw Error('Write a prompt first.');
        try { await navigator.clipboard.writeText(output.value); }
        catch {
            output.focus(); output.select();
            if (!document.execCommand('copy')) throw Error('Prompt selected. Press Ctrl+C to copy.');
        }
        status.dataset.kind = 'success';
        status.textContent = 'Copied. Paste it into your Krea workflow.';
    }, outputHead);
    output = field('Your Krea prompt — editable', 'textarea', { value: state.output || '', rows: 10,
        placeholder: 'Your generated prompt will appear here. You can also edit it directly.' }, right, 'kw-output');
    change = field('Refine · what should change?', 'textarea', { value: state.change || '', rows: 2,
        placeholder: 'Keep everything else; change the lighting to sunset…' }, right, 'kw-change');
    const rightActions = el('div', { className: 'kw-actions' }, right);
    button('↻ Refine prompt', () => write('refine'), rightActions).dataset.write = '1';
    status = el('p', { className: 'kw-status', textContent: 'Loading…' }, right);
    status.setAttribute('role', 'status');

    const advanced = el('details', { className: 'kw-advanced' }, dialog);
    el('summary', { textContent: '⚙ Settings & writer instructions' }, advanced);
    const advancedBody = el('div', { className: 'kw-advanced-body' }, advanced);
    const opts = el('div', { className: 'kw-picks kw-options' }, advancedBody);
    tokens = field('Max output tokens', 'input', { type: 'number', min: 256, max: 8192, step: 256, value: state.tokens || 1536 }, opts);
    temperature = field('Temperature', 'input', { type: 'number', min: 0, max: 2, step: 0.1, value: state.temperature ?? 0.7 }, opts);
    el('p', { className: 'kw-help', textContent: 'Model release is always on: unloads the Ollama writer model after each run, even when generation fails. It does not unload Krea or other ComfyUI models.' }, advancedBody);
    system = field('System instructions', 'textarea', { value: state.system ?? '', rows: 7 }, advancedBody);
    button('Restore upgraded instructions', () => {
        system.value = official; save(); status.dataset.kind = '';
        status.textContent = 'Default instructions restored.';
    }, advancedBody);

    for (const control of [brief, output, change, tokens, temperature, system, model, style, length, mode, mustKeep, review]) {
        control.addEventListener('change', save);
    }
    for (const control of [brief, output, change, system, mustKeep]) control.addEventListener('input', save);
    dialog.addEventListener('cancel', save);
}
async function open() {
    build();
    if (!dialog.open) dialog.showModal();
    try {
        if (!official) {
            const data = await request('config'); official = data.system;
            if (state.version !== 2 || state.system == null || legacyPreset(state.system)) {
                system.value = official;
            }
        }
        if (!model.options.length) await refresh();
    } catch (error) { status.dataset.kind = 'error'; status.textContent = error.message; }
}
// The ComfyUI Desktop graph, overlays, and side panels can sit above a button
// styled with a low CSS z-index. Keep the launcher visible even when an
// extension stylesheet is delayed, blocked, or overridden by the host UI.
let launcherDomReadyScheduled = false;
function ensureLauncher() {
    if (!document.body) {
        if (!launcherDomReadyScheduled) {
            launcherDomReadyScheduled = true;
            document.addEventListener('DOMContentLoaded', () => {
                launcherDomReadyScheduled = false;
                ensureLauncher();
            }, { once: true });
        }
        return;
    }
    let launcher = document.getElementById('krea2-writer-launcher');
    if (!launcher) {
        launcher = el('button', { id: 'krea2-writer-launcher', type: 'button' }, document.body);
    } else if (launcher.parentElement !== document.body) {
        document.body.append(launcher);
    }
    launcher.textContent = 'Krea 2 Writer';
    launcher.title = 'Open Prompt Writer for Krea 2';
    launcher.onclick = open;
    launcher.setAttribute('aria-label', 'Open Krea 2 Prompt Writer');
    // Inline !important deliberately wins against existing ComfyUI theme CSS.
    const critical = {
        'position': 'fixed', 'right': '24px', 'bottom': '142px',
        'z-index': '2147483647', 'display': 'inline-flex',
        'visibility': 'visible', 'opacity': '1', 'pointer-events': 'auto',
        'align-items': 'center', 'justify-content': 'center',
        'background': '#88dbb7', 'color': '#12231c',
        'border': '1px solid #b3f4d8', 'border-radius': '24px',
        'padding': '11px 18px', 'font': '600 14px system-ui',
        'box-shadow': '0 4px 18px #0009', 'cursor': 'pointer',
        'min-height': '38px', 'white-space': 'nowrap'
    };
    for (const [name, value] of Object.entries(critical)) {
        launcher.style.setProperty(name, value, 'important');
    }
}
function ensureLauncherStyles() {
    if (!document.querySelector('link[data-krea-writer="1"]')) {
        const css = el('link', { rel: 'stylesheet', href: new URL('./writer.css', import.meta.url).href }, document.head);
        css.dataset.kreaWriter = '1';
    }
}
function mountLauncher() {
    ensureLauncherStyles();
    ensureLauncher();
}
app.registerExtension({
    name: 'Krea2.PromptWriter',
    async init() { mountLauncher(); },
    async setup() { mountLauncher(); }
});

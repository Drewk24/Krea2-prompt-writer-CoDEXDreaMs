import asyncio
import json
import os
import re
from pathlib import Path
from urllib.parse import urlsplit
import aiohttp
from aiohttp import web
from server import PromptServer

ROOT = Path(__file__).parent
DEFAULT = (ROOT / 'prompts' / 'writer_v2.txt').read_text(encoding='utf-8')
# Server-side setting only: browser requests cannot choose arbitrary destinations.
OLLAMA_URL = os.environ.get('KREA2_OLLAMA_URL', 'http://127.0.0.1:11434').rstrip('/')
LOCK = asyncio.Lock()
routes = PromptServer.instance.routes

class WriterError(Exception):
    pass

def clean_output(text):
    text = re.sub(r'<think\b[^>]*>.*?</think>', '', text, flags=re.S | re.I)
    if re.search(r'<think\b', text, flags=re.I):
        raise WriterError('The model returned unfinished thinking. Increase Max output tokens or choose another model.')
    text = text.strip()
    if not text:
        raise WriterError('The model returned no prompt. Increase Max output tokens or choose another model.')
    return text

def payload(data):
    if not isinstance(data, dict):
        raise ValueError('Expected a JSON object.')
    model = data.get('model', '')
    brief = data.get('brief', '')
    system = data.get('system', DEFAULT)
    for name, value, limit in [('model', model, 512), ('brief', brief, 24000), ('system', system, 24000)]:
        if not isinstance(value, str) or not value.strip() or len(value) > limit:
            raise ValueError(f'{name} must contain 1–{limit} characters.')
    tokens = int(data.get('max_tokens', 1536))
    if not 256 <= tokens <= 8192:
        raise ValueError('Max output tokens must be between 256 and 8192.')
    temperature = float(data.get('temperature', 0.7))
    if not 0 <= temperature <= 2:
        raise ValueError('Temperature must be between 0 and 2.')
    style = data.get('style', 'Follow my brief')
    length = data.get('length', 'Balanced')
    mode = data.get('mode', 'New image')
    keep = data.get('must_keep', '')
    if style not in ['Follow my brief', '2D comic / cel shaded', 'Anime / hand drawn', 'Photograph', '3D render'] or length not in ['Short', 'Balanced', 'Detailed'] or mode not in ['New image', 'Reference / edit']:
        raise ValueError('Invalid writing option.')
    if not isinstance(keep, str) or len(keep) > 8000:
        raise ValueError('Must keep is too long.')
    target = {'Short': 'Aim for 70–110 words.', 'Balanced': 'Aim for 120–190 words.', 'Detailed': 'Aim for 190–280 words.'}[length]
    controls = f"\nWRITING CONTROLS: Mode: {mode}. Style preference: {style}. {target} These are soft length targets, not a word quota. In NEW IMAGE mode, add imaginative, relevant visual information instead of paraphrasing the input. In REFERENCE / EDIT mode, preserve the described source and limit additions to the requested change. Explicit brief instructions override a conflicting style selection. Must keep constraints are below; preserve them unless the latest refinement explicitly changes them.\nMust keep: {keep or '(none)'}"
    messages = [{'role': 'system', 'content': system + controls}, {'role': 'user', 'content': brief}]
    if data.get('action', 'write') == 'refine':
        current, change = data.get('current', ''), data.get('change', '')
        if not all(isinstance(x, str) and x.strip() and len(x) <= 24000 for x in [current, change]):
            raise ValueError('Refine needs an existing prompt and your requested change (up to 24000 characters each).')
        messages.extend([{'role': 'assistant', 'content': current}, {'role': 'user', 'content': change}])
    elif data.get('action', 'write') != 'write':
        raise ValueError('Unknown action.')
    return {'model': model.strip(), 'messages': messages, 'stream': False,
            'think': False, 'keep_alive': 0,
            'options': {'temperature': temperature, 'num_predict': tokens, 'num_ctx': 16384}}

async def ollama(method, path, data=None):
    timeout = aiohttp.ClientTimeout(total=300 if path == '/api/chat' else 15)
    try:
        async with aiohttp.ClientSession(timeout=timeout, trust_env=False) as session:
            async with session.request(method, OLLAMA_URL + path, json=data, allow_redirects=False) as response:
                text = await response.text()
                try:
                    result = json.loads(text)
                except ValueError:
                    raise WriterError(f'Ollama returned a non-JSON response (HTTP {response.status}).')
                if not isinstance(result, dict):
                    raise WriterError('Ollama returned an invalid response.')
                if response.status != 200:
                    raise WriterError(str(result.get('error', f'Ollama HTTP {response.status}'))[:1200])
                if not isinstance(result, dict):
                    raise WriterError('Ollama returned an invalid response.')
                if result.get('error'):
                    raise WriterError(str(result['error'])[:1200])
                return result
    except asyncio.TimeoutError:
        raise WriterError('Ollama timed out. Try a smaller model or fewer output tokens.')
    except aiohttp.ClientError:
        raise WriterError('Cannot reach Ollama. Open the Ollama app on the ComfyUI computer, then refresh models.')

async def release_model(model):
    """Explicitly unload the prompt LLM from Ollama's system RAM and GPU VRAM."""
    result = await ollama('POST', '/api/generate', {
        'model': model, 'keep_alive': 0, 'stream': False
    })
    if result.get('done_reason') not in ('unload', None):
        raise WriterError('Ollama did not confirm that the model unloaded.')
    return result.get('done_reason') == 'unload'


async def complete(request):
    try:
        result = await ollama('POST', '/api/chat', request)
    except WriterError as exc:
        message = str(exc).lower()
        if 'think' not in message or not any(s in message for s in ['not support', 'unsupported', 'unknown']):
            raise
        request.pop('think', None)
        result = await ollama('POST', '/api/chat', request)
    if result.get('done_reason') == 'length':
        raise WriterError('The response hit Max output tokens. Increase it and write again; the previous prompt is preserved.')
    message = result.get('message')
    if not isinstance(message, dict):
        raise WriterError('Ollama returned an invalid message.')
    content = message.get('content', '')
    if not isinstance(content, str):
        raise WriterError('Ollama returned invalid prompt text.')
    return clean_output(content)

async def generate(data):
    request = payload(data)
    review = data.get('review', True)
    if not isinstance(review, bool):
        raise ValueError('Review must be true or false.')
    # Reject oversized requests instead of silently losing early constraints.
    if sum(len(m['content']) for m in request['messages']) + request['options']['num_predict'] * 4 > 52000:
        raise ValueError('Shorten the brief or instructions to fit the context.')
    final_keep_alive = request['keep_alive']
    if review:
        request['keep_alive'] = '5m'
    draft = await complete(request)
    if not review:
        return draft
    request['messages'].extend([
        {'role': 'assistant', 'content': draft},
        {'role': 'user', 'content': 'Polish this draft into the final Krea 2 image prompt. Check exact subject count, identities, props, handedness, framing, requested medium, literal quoted words, must-keep requirements and latest requested change. Fix contradictions, missed requirements, awkward descriptions and irrelevant clutter. IMPORTANT: In NEW IMAGE mode, preserve the imaginative supporting details, composition, textures and atmosphere that make the draft more useful than the original idea; improve weakly specified visuals when needed. Do NOT compress it into a paraphrase or delete fitting invented details merely because they were not in the brief. In REFERENCE / EDIT mode, do not add unrequested changes. Keep approximately the draft’s visual richness, while respecting the selected length and constraints. Return ONLY one natural-language paragraph with the final image prompt.'}
    ])
    request['keep_alive'] = final_keep_alive
    request['options']['temperature'] = min(request['options']['temperature'], 0.35)
    return await complete(request)

def same_origin(request):
    origin = request.headers.get('Origin')
    return not origin or urlsplit(origin).netloc == request.host

@routes.get('/krea2-writer/config')
async def config(request):
    return web.json_response({'system': DEFAULT, 'version': '2.2.1'})

@routes.get('/krea2-writer/models')
async def models(request):
    try:
        result = await ollama('GET', '/api/tags')
        names = sorted({m['name'] for m in result.get('models', []) if isinstance(m.get('name'), str)})
        return web.json_response({'models': names})
    except WriterError as exc:
        return web.json_response({'error': str(exc)}, status=502)

@routes.post('/krea2-writer/write')
async def write(request):
    if not same_origin(request):
        return web.json_response({'error': 'Cross-origin request blocked.'}, status=403)
    if LOCK.locked():
        return web.json_response({'error': 'A prompt is already being written. Wait for it to finish.'}, status=409)
    try:
        async with LOCK:
            data = await request.json()
            # Keep the writer's Ollama model between quality-review passes, then
            # explicitly unload it even if a pass fails or returns malformed text.
            model_name = payload(data)['model']
            release_confirmed = False
            release_warning = None
            try:
                result = await generate(data)
            finally:
                try:
                    release_confirmed = await release_model(model_name)
                except (WriterError, aiohttp.ClientError, asyncio.TimeoutError) as exc:
                    # Never discard a finished prompt merely because Ollama's
                    # cleanup endpoint was unavailable; report the failure.
                    release_warning = 'Ollama release failed: ' + str(exc)
            return web.json_response({'prompt': result, 'model_unloaded': release_confirmed,
                                      'unload_warning': release_warning})
    except (ValueError, TypeError, OverflowError):
        return web.json_response({'error': 'Invalid input. Check the brief, model, settings and refinement text.'}, status=400)
    except WriterError as exc:
        return web.json_response({'error': str(exc)}, status=502)

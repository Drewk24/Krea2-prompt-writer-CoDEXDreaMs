# Prompt Writer for Krea 2 v2.2.1
October 8, 2026

**Unofficial third-party ComfyUI utility. Not affiliated with or endorsed by Krea.ai.**

This extension writes and refines image prompts for use with Krea 2 workflows. It does **not** include Krea 2 model weights, Krea source code, Krea documentation, or Krea's official prompt-expansion text.

## Customer installation (Windows)
1. **Close ComfyUI Desktop / portable ComfyUI.**
2. Unzip the customer package. It contains `INSTALL.cmd`, `INSTALL.ps1`, `START-HERE.txt`, and the `ComfyUI-Krea2-Prompt-Writer` extension folder.
3. **Recommended:** copy those items to **your own ComfyUI folder containing `main.py` and `custom_nodes`**, then double-click `INSTALL.cmd` there. It automatically installs the extension into the correct `custom_nodes` location relative to where you ran it.
4. You can also run `INSTALL.cmd` from anywhere; it will ask for your ComfyUI folder if it isn't beside `main.py`. It never uses a predefined account, drive, or developer install path.
5. Restart ComfyUI and press `Ctrl+F5`. Click **Krea 2 Writer**.

**Simplest manual alternative:** copy the supplied `ComfyUI-Krea2-Prompt-Writer` directory directly into `YOUR_COMFYUI\custom_nodes\`. This extension has no extra pip requirements beyond what ComfyUI normally includes.

On upgrades, the installer first stages the new files, backs up any installed copy under `YOUR_COMFYUI\krea-writer-backups`, and attempts rollback if activation fails. No administrator rights needed for a normal user-owned installation.

Advanced option: `powershell -NoProfile -ExecutionPolicy Bypass -File INSTALL.ps1 -ComfyRoot "D:\Your\ComfyUI"` (replace example with your own path).

## Compact single-window layout (new in v2.1.0)
The writer now opens in **one non-scrolling desktop panel**: idea, model, task/style/detail, Must Keep, and Write on the left; editable output, Copy, and Refine on the right. Advanced settings remain in the same window, collapsed until needed. Text boxes scroll internally for long prompts. Narrow mobile-size windows use a stacked layout and may scroll.

## Rich prompt-writing update (v2.2.0)
New-image mode turns brief ideas into fuller, more atmospheric, visually directed prompts with coherent setting, staging, expression, materials and lighting, while preserving specified characters, clothing, text and compositions. The default **Balanced** setting aims for about 120–190 words when the concept supports it; Short and Detailed are available. Reference / edit mode and refinement remain conservative about altering existing designs. The two-pass review now improves the result instead of stripping useful visual development.

**Existing installations:** Updating automatically replaces the **exact unchanged v2.1.1 system preset** in browser storage; independently edited/custom system instructions are preserved. To switch a custom preset to the new creative preset, open **Settings & writer instructions** and click **Restore upgraded instructions**.

## Use
Choose an installed Ollama model. Describe the image. Put exact traits, proportions, clothing, framing, visible text, or supplied trigger words in **Must keep**. Click **Write prompt**, then **Copy prompt** and paste the result into your Krea 2 workflow.

Style defaults to **Follow my brief**. Optional presets cover comic/cel shading, drawn anime, photography, and 3D. Explicit instructions in the brief take priority. Short/Balanced/Detailed are soft length targets; new-image prompts should meaningfully develop the user's idea rather than merely repeat it.

**Quality review** is ON by default. A second local model call checks the draft against the original request and constraints **while keeping helpful imaginative scene detail**. Turn it OFF for one-pass speed. This check can still miss mistakes; review the result before generating.

For revisions, edit the output directly or use **What should change?** + **Refine prompt**. Refinement is instructed to keep everything else unchanged. **Reference / edit** mode uses your written description only; this writer cannot see images.

## What is included
- Floating ComfyUI UI; no graph nodes.
- Local Ollama model selection.
- Write / review / refine / copy workflow.
- Style, detail, task, and Must keep controls.
- Editable custom system instructions stored locally in the browser.
- No Krea model weights, Krea source code, or official Krea prompt text.

## Settings and limitations
Max output defaults to 1536 tokens. System instructions are editable under **Settings / writer instructions**. **Restore upgraded instructions** restores this extension's custom defaults.

Requires an existing local Ollama installation/model and running Ollama. The default address is `http://127.0.0.1:11434`; `KREA2_OLLAMA_URL` can change it server-side. The extension does not modify your ComfyUI graph or generate images. Model choice affects instruction following. Prompt wording cannot guarantee image quality or fix diffusion/model settings.

**Automatic Ollama unload is always enabled** and cannot be turned off in this version. The writer sends `keep_alive: 0` on the last generation call, **and also calls Ollama's `/api/generate` unload endpoint in a `finally` cleanup step** after every attempted Write/Refine action, even when the two-pass review or generation fails. The UI confirms a successful unload request or displays an explicit warning if cleanup fails. This targets the selected **Ollama LLM** in GPU VRAM and system RAM; it does not unload unrelated ComfyUI/Krea diffusion models. If Ollama itself crashes, is disconnected, or cannot answer the unload request, cleanup cannot be guaranteed and a later manual Ollama restart may be necessary. Each chat request times out after five minutes. Browser drafts are local to the browser origin.

## Verification
The included 16-case backend suite covers write/refine, review passes, constraint forwarding, unload behavior, invalid controls, context guard, unsupported-thinking fallback, connection failures, truncated/empty replies, concurrency, and origin checks.

Run backend tests:
`python -m unittest discover -s tests -v`

JavaScript syntax check:
`node --check web/writer.js`

Browser integration test:
`node tests/test-ui.cjs` (requires Playwright and Chromium)

## Compatibility / naming notice
“Krea 2” and “Krea.ai” are referenced only to describe the intended compatibility/use of this independent utility. This package is not an official Krea product and does not claim Krea sponsorship or endorsement.

Ollama is a separate local application and is not bundled with this extension.

## Launcher visibility fix (v2.2.1)
Fixed a broken JavaScript string that prevented the floating button from loading. The Krea 2 Writer button is mounted from both supported frontend startup hooks, waits for the document body when necessary, and uses a high-priority fixed visual style so it stays above ComfyUI Desktop canvas and panels. The actual writer dialog and Ollama logic are unchanged.
